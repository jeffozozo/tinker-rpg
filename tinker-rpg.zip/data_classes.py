"""
Updated data_classes.py with enhanced trigger system
"""

from uuid import uuid4
from item_rules import item_defaults
from dataclasses import dataclass, asdict
from typing import Dict, List, Optional, Any

MAX_AREA_DIMENSION = 100
MAX_PLAYER_INVENTORY_SLOTS = 8
PLAYER_STAT_CHANGES = ("health", "energy", "gold", "strength", "intelligence", "max_health", "max_energy")

def funds_delta(parameters):
    action, amount = parameters.get("action", "add"), parameters.get("amount", 0)
    if action not in ("add", "remove"):
        raise ValueError("Funds action must be add or remove.")
    if type(amount) is not int or amount <= 0:
        raise ValueError("Funds amount must be a positive whole number.")
    return amount if action == "add" else -amount


def trigger_charges(parameters):
    """0 is unlimited; legacy once=True is equivalent to one charge."""
    if type(parameters.get("once", False)) is not bool:
        raise ValueError("once must be true or false.")
    charges = parameters.get("charges", 1 if parameters.get("once", False) else 0)
    if type(charges) is not int or charges < 0:
        raise ValueError("Charges must be a whole number of zero or greater (0 = unlimited).")
    return charges


@dataclass
class Tile:
    """Represents a single tile in the game world"""
    type: str = "empty"
    walkable_override: Optional[bool] = None
    properties: Dict[str, Any] = None
    
    def __post_init__(self):
        if self.properties is None:
            self.properties = {}
    
    def is_walkable(self, tile_manager):
        if self.walkable_override is not None:
            return self.walkable_override
        return tile_manager.get_default_walkable(self.type)

@dataclass
class GameObject:
    """Represents NPCs, items, or interactive objects"""
    type: str = "npc"
    x: int = 0
    y: int = 0
    properties: Dict[str, Any] = None
    
    def __post_init__(self):
        if self.properties is None:
            self.properties = {}

def ensure_enemy_instance_ids(area):
    """Give placed enemies persistent identities independent of type and position."""
    seen = set()
    for obj in area.objects:
        if "enemy_id" not in obj.properties and "enemy_data" not in obj.properties:
            continue
        identity = obj.properties.setdefault("enemy_instance_id", f"enemy_instance_{uuid4().hex}")
        if not isinstance(identity, str) or not identity or identity in seen:
            raise ValueError("Placed enemies need unique, non-empty instance IDs.")
        seen.add(identity)


@dataclass
class Trigger:
    """Represents a trigger tile that executes actions"""
    x: int = 0
    y: int = 0
    trigger_type: str = "teleport"  # Action type; activation may be walking or enemy defeat.
    name: str = ""  # User-entered name
    parameters: Dict[str, Any] = None  # Type-specific parameters
    enemy_attached: str = ""
    enemy_defeated: bool = False  # Runtime activation state, persisted in saves.
    enemy_pending: bool = False
    
    def __post_init__(self):
        if self.parameters is None:
            self.parameters = {}
        if self.trigger_type == "show_dialog":
            self.trigger_type = "show_message"
        if not self.name:
            # Set default name - will be updated to trigger_1, trigger_2, etc.
            self.name = "trigger_1"
    
    def get_description(self):
        """Get a brief description of what this trigger does"""
        if self.trigger_type == "teleport":
            area = self.parameters.get("area", "")
            x = self.parameters.get("x", 0)
            y = self.parameters.get("y", 0)
            return f"Teleport to {area} ({x},{y})"
        elif self.trigger_type == "inventory":
            add_item = self.parameters.get("add", "")
            remove_item = self.parameters.get("remove", "")
            parts = []
            if add_item:
                parts.append(f"Add: {add_item}")
            if remove_item:
                parts.append(f"Remove: {remove_item}")
            return ", ".join(parts) if parts else "Inventory change"
        elif self.trigger_type == "funds":
            action = "Remove" if self.parameters.get("action") == "remove" else "Add"
            return f"{action} ${self.parameters.get('amount', 0)}"
        elif self.trigger_type == "player_stats":
            stat = self.parameters.get("stat", "health").replace("_", " ").title()
            amount = self.parameters.get("amount", 0)
            return f"{stat}: {amount:+d}" if type(amount) is int else f"{stat}: {amount}"
        elif self.trigger_type == "tile_update":
            tile = self.parameters.get("tile", "")
            x = self.parameters.get("x", 0)
            y = self.parameters.get("y", 0)
            return f"Change tile at ({x},{y}) to {tile}"
        elif self.trigger_type == "area_object":
            area = self.parameters.get("area", "")
            obj = self.parameters.get("object", "")
            action = "Remove" if self.parameters.get("action") == "remove" else "Add"
            relation = "from" if action == "Remove" else "to"
            return f"{action} {obj} {relation} {area or 'this area'}"
        elif self.trigger_type == "game_end":
            result = self.parameters.get("win_lose", "win")
            return f"Game {result}"
        elif self.trigger_type == "show_message":
            message = self.parameters.get("message", "")[:30]
            return f"Message: \"{message}...\""
        elif self.trigger_type == "custom":
            return "Custom script"
        return "Unknown trigger"

@dataclass
class Area:
    """Represents a game area/map"""
    name: str = "Untitled Area"
    width: int = 20
    height: int = 15
    tiles: List[List[Tile]] = None
    objects: List[GameObject] = None
    triggers: List[Trigger] = None
    
    def __post_init__(self):
        if self.tiles is None:
            self.tiles = [[Tile() for _ in range(self.width)] for _ in range(self.height)]
        if self.objects is None:
            self.objects = []
        if self.triggers is None:
            self.triggers = []

@dataclass
class Game:
    """Represents a complete game project"""
    name: str = "Untitled Game"
    areas: List[str] = None  # List of area filenames
    used_tiles: List[str] = None  # Tiles used in this game
    used_npcs: List[str] = None  # NPCs used in this game
    used_objects: List[str] = None  # Objects used in this game
    used_triggers: List[str] = None  # Triggers used in this game
    properties: Dict[str, Any] = None
    object_definitions: Dict[str, Dict[str, Any]] = None
    intro_message: str = ""
    instructions_message: str = ""
    game_end_message: str = ""
    
    def __post_init__(self):
        if self.areas is None:
            self.areas = []
        if self.used_tiles is None:
            self.used_tiles = []
        if self.used_npcs is None:
            self.used_npcs = []
        if self.used_objects is None:
            self.used_objects = []
        if self.used_triggers is None:
            self.used_triggers = []
        if self.properties is None:
            self.properties = {}
        if self.object_definitions is None:
            self.object_definitions = {}

    def get_object_definition(self, object_type: str) -> Dict[str, Any]:
        definition = {
            "gettable": False,
            "walkable": True,
            "effect_mode": "passive",
            "effects": {
                "health": 0,
                "energy": 0,
                "armor": 0,
                "attack": 0,
            },
        }
        definition.update(item_defaults(object_type))
        stored_definition = self.object_definitions.get(object_type, {})
        definition.update(stored_definition)
        # Recognize helmets/shields authored before dedicated equipment fields existed.
        stored_effects = stored_definition.get("effects", {})
        if not isinstance(stored_effects, dict):
            raise ValueError("Item effects must be an object.")
        legacy_armor = stored_effects.get("armor", 0)
        if (object_type in ("helmet_object", "shield_object")
                and "armor_bonus" not in stored_definition
                and stored_definition.get("item_type", "object") == "object"
                and type(legacy_armor) is int and legacy_armor > 0):
            definition["item_type"] = "armor"
            definition["armor_bonus"] = legacy_armor
        if stored_definition.get("item_type", "object") == "object" and stored_definition.get("effect_mode") == "consumable":
            definition["item_type"] = "consumable"
        definition["effects"] = {
            **{"health": 0, "energy": 0, "armor": 0, "attack": 0},
            **stored_definition.get("effects", {}),
        }
        return definition