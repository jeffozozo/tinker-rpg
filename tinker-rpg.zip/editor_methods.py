from item_rules import ITEM_TYPES, compatible_slot, validate_item
"""
Updated editor_methods.py with enhanced trigger system
"""

import tkinter as tk
from tkinter import ttk, filedialog, messagebox
import json
import os
from dataclasses import asdict

from data_classes import MAX_PLAYER_INVENTORY_SLOTS, PLAYER_STAT_CHANGES, trigger_charges, funds_delta, ensure_enemy_instance_ids
from project_paths import project_root

class EditorMethods:
    """Mixin class containing all editor interaction methods"""
    
    def __init__(self):
        # Add trigger selection tracking
        self.selected_trigger_index = 0
        self.trigger_colors = {
            "teleport": "#0066CC",      # Blue
            "funds": "#B8860B",
            "player_stats": "#B2498A",
            "inventory": "#009900",     # Green
            "tile_update": "#FFCC00",   # Yellow
            "area_object": "#FF6600",   # Orange
            "game_end": "#9900CC",      # Purple
            "show_message": "#00CCCC",   # Cyan
            "custom": "#CC0000"         # Red
        }

    def get_player_settings(self):
        properties = self.current_game.properties
        player = properties.setdefault("player", {})
        player.setdefault("sprite", "fighter_npc")
        player.setdefault("starting_inventory", [])
        defaults = {
            "starting_health": 20,
            "max_health": 20,
            "starting_energy": 0,
            "max_energy": 0,
            "strength": 1,
            "intelligence": 1,
            "gold": 0,
        }
        stats = player.setdefault("stats", {})
        for key, value in defaults.items():
            stats.setdefault(key, value)
        properties.setdefault("start_area", "")
        properties.setdefault("start_x", 0)
        properties.setdefault("start_y", 0)
        return player

    def setup_player_inventory(self, parent):
        self.player_inventory_frame = ttk.LabelFrame(
            parent, text=f"Starting Inventory ({MAX_PLAYER_INVENTORY_SLOTS} slots)"
        )
        ttk.Label(
            self.player_inventory_frame,
            text="Mark objects Gettable to add them here.",
        ).pack(anchor=tk.W, padx=4, pady=(3, 1))
        self.player_inventory_vars = []
        self.player_inventory_selectors = []
        for index in range(MAX_PLAYER_INVENTORY_SLOTS):
            row = ttk.Frame(self.player_inventory_frame)
            row.pack(fill=tk.X, padx=4, pady=1)
            ttk.Label(row, text=f"{index + 1}:", width=3).pack(side=tk.LEFT)
            variable = tk.StringVar()
            selector = ttk.Combobox(
                row, textvariable=variable, state="readonly", width=19
            )
            selector.pack(side=tk.LEFT, fill=tk.X, expand=True)
            self.player_inventory_vars.append(variable)
            self.player_inventory_selectors.append(selector)
        ttk.Button(
            self.player_inventory_frame,
            text="Clear Starting Inventory",
            command=self.clear_player_inventory,
        ).pack(fill=tk.X, padx=4, pady=(3, 4))
        self.player_inventory_frame.pack_forget()

    def clear_player_inventory(self):
        for variable in getattr(self, "player_inventory_vars", []):
            variable.set("")

    def refresh_player_inventory(self):
        variables = getattr(self, "player_inventory_vars", [])
        if not variables:
            return
        player = self.get_player_settings()
        inventory = player.get("starting_inventory", [])
        if not isinstance(inventory, list):
            inventory = []
        available_items = self._available_inventory_items()
        for item in inventory:
            if isinstance(item, str) and item and item not in available_items:
                available_items.append(item)
        choices = [""] + available_items
        for selector, variable, index in zip(
            self.player_inventory_selectors, variables, range(len(variables))
        ):
            selector.configure(values=choices)
            item = inventory[index] if index < len(inventory) else ""
            variable.set(item if isinstance(item, str) else "")

    def _available_inventory_items(self):
        return sorted(
            item for item in self.tile_manager.get_object_names()
            if self.current_game.get_object_definition(item).get("gettable")
        )

    def _player_start_area_text(self):
        start_area = self.current_game.properties.get("start_area")
        return f"Start area: {start_area or 'Not set'}"

    def _player_start_position_text(self):
        properties = self.current_game.properties
        return f"Start position: ({properties.get('start_x', 0)}, {properties.get('start_y', 0)})"

    def refresh_player_setup(self):
        player = self.get_player_settings()
        if hasattr(self, "player_start_area_label"):
            self.player_start_area_label.config(text=self._player_start_area_text())
            self.player_start_position_label.config(
                text=self._player_start_position_text()
            )
        for key, variable in getattr(self, "player_stat_vars", {}).items():
            variable.set(str(player["stats"][key]))
        self.refresh_player_inventory()
        if hasattr(self, "remember_editor_form"):
            self.remember_editor_form("player", [*getattr(self, "player_stat_vars", {}).values(),
                                                 *getattr(self, "player_inventory_vars", [])])

    def save_player_setup(self):
        player = self.get_player_settings()
        try:
            stats = {
                key: int(variable.get())
                for key, variable in self.player_stat_vars.items()
            }
        except ValueError:
            messagebox.showerror("Invalid Player Settings", "Player stats must be whole numbers.")
            return False
        if any(value < 0 for value in stats.values()) or stats["max_health"] < 1:
            messagebox.showerror(
                "Invalid Player Settings",
                "Stats cannot be negative, and maximum health must be at least 1.",
            )
            return False
        if stats["starting_health"] < 1:
            messagebox.showerror(
                "Invalid Player Settings",
                "Starting health must be at least 1.",
            )
            return False
        if stats["starting_health"] > stats["max_health"]:
            messagebox.showerror(
                "Invalid Player Settings",
                "Starting health cannot exceed maximum health.",
            )
            return False
        if stats["starting_energy"] > stats["max_energy"]:
            messagebox.showerror(
                "Invalid Player Settings",
                "Starting energy cannot exceed maximum energy.",
            )
            return False
        inventory_vars = getattr(self, "player_inventory_vars", None)
        if inventory_vars is not None:
            inventory = [
                variable.get().strip() for variable in inventory_vars
            ]
            if len(inventory) > MAX_PLAYER_INVENTORY_SLOTS:
                messagebox.showerror(
                    "Invalid Player Inventory",
                    f"Starting inventory can contain at most {MAX_PLAYER_INVENTORY_SLOTS} slots.",
                )
                return False
            old_inventory = player.get("starting_inventory", [])
            old_items = (
                {item for item in old_inventory if isinstance(item, str)}
                if isinstance(old_inventory, list)
                else set()
            )
            available_items = set(self._available_inventory_items()) | old_items
            invalid_items = sorted(
                item for item in inventory if item and item not in available_items
            )
            if invalid_items:
                messagebox.showerror(
                    "Invalid Player Inventory",
                    "Choose items from the available object list.",
                )
                return False
            player["starting_inventory"] = inventory
        player["stats"] = stats
        if hasattr(self, "remember_editor_form"):
            self.remember_editor_form("player", [*getattr(self, "player_stat_vars", {}).values(),
                                                 *getattr(self, "player_inventory_vars", [])])
        return True

    def set_player_start(self, x, y):
        if (not self.current_area_file or
                not self._is_project_area(self.current_area_file)):
            messagebox.showwarning(
                "Player Start",
                "Save this area in the project's areas folder before setting it as the start area.",
            )
            return False
        if not (0 <= x < self.current_area.width and 0 <= y < self.current_area.height):
            messagebox.showwarning(
                "Player Start", "Choose a tile inside the area for the player start."
            )
            return False

        area_filename = os.path.basename(self.current_area_file)
        if area_filename not in self.current_game.areas:
            self.current_game.areas.append(area_filename)

        properties = self.current_game.properties
        properties["start_area"] = area_filename
        properties["start_x"] = x
        properties["start_y"] = y
        player = self.get_player_settings()
        player["sprite"] = self.selected_tile
        self.refresh_game_areas_list()
        self.refresh_player_setup()
        self.draw_area()
        self.update_properties_display()
        return True
    
    def on_key_press(self, event):
        key = event.keysym.lower()
        if getattr(self, "_trigger_position_picker", None) is not None:
            if key == "escape":
                self._trigger_position_picker = None
                self._restore_coordinate_picker_area()
            return "break"
        if self.root.focus_get() == self.canvas:
            if self.selected_mode in ("messages", "editor_help"):
                return "break"
            if key in ['up', 'down', 'left', 'right']:
                self.move_cursor(key)
                return "break"
            elif key == 'space':
                self.place_tile()
                return "break"
            elif key == 'delete' or key == 'backspace':
                self.remove_tile()
                return "break"
            elif key in ['1', '2', '3', '4', '5', '6', '7', '8', '9', '0']:
                self.select_trigger(10 if key == "0" else int(key))
                return "break"
            elif key == 'return':  # Enter key
                self.edit_selected_trigger()
                return "break"
    
    def select_trigger(self, trigger_number):
        """Select a specific trigger at the current location"""
        triggers_here = [trig for trig in self.current_area.triggers 
                        if trig.x == self.cursor_x and trig.y == self.cursor_y]
        if triggers_here and 1 <= trigger_number <= len(triggers_here):
            self.select_trigger_index(trigger_number - 1)

    def select_trigger_index(self, index):
        triggers_here = self._triggers_at_cursor()
        if not triggers_here or not 0 <= index < len(triggers_here):
            return False
        if index == self.selected_trigger_index:
            return True
        if not self.save_selected_trigger(show_error=True, refresh=False):
            return False
        self.selected_trigger_index = index
        self.refresh_trigger_editor()
        self.update_properties_display()
        self.draw_area()
        return True

    def edit_selected_trigger(self):
        """Focus the selected trigger editor in the properties panel."""
        self.refresh_trigger_editor()
    
    def get_next_trigger_name(self):
        """Generate the next available trigger name (trigger_1, trigger_2, etc.)"""
        existing_names = [trig.name for trig in self.current_area.triggers]
        counter = 1
        while f"trigger_{counter}" in existing_names:
            counter += 1
        return f"trigger_{counter}"
    
    def place_tile(self):
        if self.selected_mode == "player":
            self.set_player_start(self.cursor_x, self.cursor_y)
        elif self.selected_mode == "enemy":
            self.place_selected_enemy()
        elif self.selected_mode == "tile":
            current_tile = self.current_area.tiles[self.cursor_y][self.cursor_x]
            if current_tile.type == self.selected_tile:
                from data_classes import Tile
                self.current_area.tiles[self.cursor_y][self.cursor_x] = Tile(type="empty")
            else:
                from data_classes import Tile
                self.current_area.tiles[self.cursor_y][self.cursor_x] = Tile(type=self.selected_tile)
        
        elif self.selected_mode == "object":
            existing = [obj for obj in self.current_area.objects 
                       if obj.x == self.cursor_x and obj.y == self.cursor_y]
            if existing and existing[0].type == self.selected_tile:
                self.current_area.objects = [obj for obj in self.current_area.objects 
                                           if not (obj.x == self.cursor_x and obj.y == self.cursor_y)]
            else:
                self.current_area.objects = [obj for obj in self.current_area.objects 
                                           if not (obj.x == self.cursor_x and obj.y == self.cursor_y)]
                from data_classes import GameObject
                self.current_area.objects.append(GameObject(
                    type=self.selected_tile, x=self.cursor_x, y=self.cursor_y))
        
        elif self.selected_mode == "npc":
            npc_types = set(self.tile_manager.get_npc_names()) or {"guard", "merchant", "villager"}
            existing = [obj for obj in self.current_area.objects 
                       if obj.x == self.cursor_x and obj.y == self.cursor_y and obj.type in npc_types]
            if existing and existing[0].type == self.selected_tile:
                self.current_area.objects = [obj for obj in self.current_area.objects 
                                           if not (obj.x == self.cursor_x and obj.y == self.cursor_y and 
                                                  obj.type in npc_types)]
            else:
                self.current_area.objects = [obj for obj in self.current_area.objects 
                                           if not (obj.x == self.cursor_x and obj.y == self.cursor_y and 
                                                  obj.type in npc_types)]
                from data_classes import GameObject
                self.current_area.objects.append(GameObject(
                    type=self.selected_tile, x=self.cursor_x, y=self.cursor_y))
        
        elif self.selected_mode == "trigger":
            triggers_here = [trig for trig in self.current_area.triggers 
                           if trig.x == self.cursor_x and trig.y == self.cursor_y]
            if self.selected_mode == "trigger" and not self.save_selected_trigger(
                show_error=True, refresh=False
            ):
                return
            if len(triggers_here) >= 10:
                messagebox.showwarning("Max Triggers", "Maximum 10 triggers allowed per location")
                return
            
            from data_classes import Trigger
            new_trigger = Trigger(
                x=self.cursor_x, 
                y=self.cursor_y,
                trigger_type=self.selected_tile,  # selected_tile now holds trigger type
                name=self.get_next_trigger_name()
            )
            self.current_area.triggers.append(new_trigger)
            self.selected_trigger_index = len(triggers_here)  # Select the new trigger
            self.refresh_trigger_editor()
        self.draw_area()
        self.update_properties_display()

    def fill_empty_tiles(self):
        if self.selected_mode != "tile":
            messagebox.showwarning(
                "Fill Empty Tiles", "Select Tiles mode before filling the area."
            )
            return 0

        from data_classes import Tile
        filled_count = 0
        for row in self.current_area.tiles:
            for x, tile in enumerate(row):
                if tile.type == "empty":
                    row[x] = Tile(type=self.selected_tile)
                    filled_count += 1

        if filled_count:
            self.draw_area()
            self.update_properties_display()
        return filled_count
    
    def remove_tile(self):
        if self.selected_mode == "tile":
            from data_classes import Tile
            self.current_area.tiles[self.cursor_y][self.cursor_x] = Tile(type="empty")
        elif self.selected_mode == "object":
            npc_types = set(self.tile_manager.get_npc_names()) or {"guard", "merchant", "villager"}
            self.current_area.objects = [obj for obj in self.current_area.objects 
                                       if not (obj.x == self.cursor_x and obj.y == self.cursor_y and 
                                              obj.type not in npc_types)]
        elif self.selected_mode == "enemy":
            self.remove_enemies_at_cursor()
        elif self.selected_mode == "npc":
            npc_types = set(self.tile_manager.get_npc_names()) or {"guard", "merchant", "villager"}
            self.current_area.objects = [obj for obj in self.current_area.objects 
                                       if not (obj.x == self.cursor_x and obj.y == self.cursor_y and 
                                              obj.type in npc_types)]
        elif self.selected_mode == "trigger":
            self.delete_selected_trigger(confirm=False)
        
        self.draw_area()
        self.update_properties_display()
    
    def move_cursor(self, direction):
        if self.selected_mode == "trigger" and not self.save_selected_trigger(
            show_error=True, refresh=False
        ):
            return
        if direction == 'up' and self.cursor_y > 0:
            self.cursor_y -= 1
        elif direction == 'down' and self.cursor_y < self.current_area.height - 1:
            self.cursor_y += 1
        elif direction == 'left' and self.cursor_x > 0:
            self.cursor_x -= 1
        elif direction == 'right' and self.cursor_x < self.current_area.width - 1:
            self.cursor_x += 1
        
        # Reset trigger selection when moving to new location
        self.selected_trigger_index = 0
        self.update_cursor_display()
        self.refresh_trigger_editor()
        self.update_properties_display()
    
    def on_canvas_click(self, event):
        position_picker = getattr(self, "_trigger_position_picker", None)
        if position_picker is not None:
            canvas_x = self.canvas.canvasx(event.x)
            canvas_y = self.canvas.canvasy(event.y)
            grid_x = int(canvas_x // self.tile_size)
            grid_y = int(canvas_y // self.tile_size)
            if (0 <= grid_x < self.current_area.width and
                    0 <= grid_y < self.current_area.height):
                position_picker["x_var"].set(str(grid_x))
                position_picker["y_var"].set(str(grid_y))
                self._trigger_position_picker = None
                self._restore_coordinate_picker_area()
            self.canvas.focus_set()
            return "break"

        if self.selected_mode in ("messages", "editor_help"):
            return

        canvas_x = self.canvas.canvasx(event.x)
        canvas_y = self.canvas.canvasy(event.y)
        grid_x = int(canvas_x // self.tile_size)
        grid_y = int(canvas_y // self.tile_size)

        trigger_variables = getattr(self, "_trigger_editor_vars", {})
        if (
            self.selected_mode == "trigger"
            and getattr(self, "_trigger_editor_trigger", None) is not None
            and getattr(self, "_trigger_editor_draft_type", None) == "tile_update"
            and "x" in trigger_variables
            and "y" in trigger_variables
        ):
            if (
                0 <= grid_x < self.current_area.width
                and 0 <= grid_y < self.current_area.height
            ):
                trigger_variables["x"].set(str(grid_x))
                trigger_variables["y"].set(str(grid_y))
                self.mouse_position_label.config(
                    text=f"Mouse: ({grid_x}, {grid_y})"
                )
            else:
                self.mouse_position_label.config(text="Mouse: --")
            self.canvas.focus_set()
            return "break"

        if self.selected_mode == "trigger" and not self.save_selected_trigger(
            show_error=True, refresh=False
        ):
            return "break"
        self.canvas.focus_set()
        
        if (0 <= grid_x < self.current_area.width and 0 <= grid_y < self.current_area.height):
            if self.selected_mode == "player":
                self.cursor_x = grid_x
                self.cursor_y = grid_y
                self.update_cursor_display()
                self.set_player_start(grid_x, grid_y)
                return "break"
            self.cursor_x = grid_x
            self.cursor_y = grid_y
            self.selected_trigger_index = 0  # Reset trigger selection
            self.update_cursor_display()
            self.refresh_trigger_editor()
            self.update_properties_display()

    def _begin_trigger_position_pick(
            self, x_var, y_var, destination_area_name=None
    ):
            area = self.current_area
            area_file = self.current_area_file
            if destination_area_name:
                destination_filename = next(
                    (
                        filename for filename in self.current_game.areas
                        if os.path.splitext(os.path.basename(filename))[0]
                        == destination_area_name
                    ),
                    None,
                )
                if destination_filename is None:
                    messagebox.showerror(
                        "Pick Coordinates",
                        "Choose a destination area that belongs to this game.",
                    )
                    return False

                destination_path = self._project_path(
                    "areas", destination_filename
                )
                if (
                    area_file
                    and os.path.realpath(area_file) == os.path.realpath(destination_path)
                ):
                    destination_area = area
                else:
                    try:
                        destination_area = self._read_area_file(destination_path)
                    except FileNotFoundError:
                        messagebox.showerror(
                            "Save Destination Area First",
                            "Save the destination area first, then choose its coordinates.",
                        )
                        return False
                    except (OSError, ValueError, TypeError, KeyError) as error:
                        messagebox.showerror(
                            "Pick Coordinates",
                            f"Could not load destination area "
                            f"{destination_filename}: {error}",
                        )
                        return False
                area = destination_area
                area_file = destination_path

            self._coordinate_picker_source = (
                self.current_area,
                self.current_area_file,
                self.cursor_x,
                self.cursor_y,
                self.selected_trigger_index,
            )
            self.current_area = area
            self.current_area_file = area_file
            self._trigger_position_picker = {"x_var": x_var, "y_var": y_var}
            try:
                target_x = int(x_var.get())
                target_y = int(y_var.get())
            except (ValueError, TypeError):
                target_x = target_y = 0
            if not (
                0 <= target_x < area.width and 0 <= target_y < area.height
            ):
                target_x = target_y = 0
            self.cursor_x, self.cursor_y = target_x, target_y
            self.draw_area()
            self.cursor_label.config(
                text=f"Click target cell in {area.name} (Esc to cancel)"
            )
            self.canvas.focus_set()
            return True

    def _restore_coordinate_picker_area(self):
            source = getattr(self, "_coordinate_picker_source", None)
            if source is None:
                self.update_cursor_display()
                return
            (
                self.current_area,
                self.current_area_file,
                self.cursor_x,
                self.cursor_y,
                self.selected_trigger_index,
            ) = source
            self._coordinate_picker_source = None
            self.draw_area()

    def on_canvas_right_click(self, event):
        if (getattr(self, "_trigger_position_picker", None) is not None or
                self.selected_mode in ("messages", "editor_help")):
            return "break"

        canvas_x = self.canvas.canvasx(event.x)
        canvas_y = self.canvas.canvasy(event.y)
        grid_x = int(canvas_x // self.tile_size)
        grid_y = int(canvas_y // self.tile_size)
        if not (0 <= grid_x < self.current_area.width and
                0 <= grid_y < self.current_area.height):
            return "break"

        if self.selected_mode == "trigger" and not self.save_selected_trigger(
            show_error=True, refresh=False
        ):
            return "break"
        self.canvas.focus_set()
        self.cursor_x = grid_x
        self.cursor_y = grid_y
        self.selected_trigger_index = 0
        self.update_cursor_display()
        self.refresh_trigger_editor()
        self.update_properties_display()
        self.place_tile()
        return "break"

    def on_canvas_motion(self, event):
        canvas_x = self.canvas.canvasx(event.x)
        canvas_y = self.canvas.canvasy(event.y)
        grid_x = int(canvas_x // self.tile_size)
        grid_y = int(canvas_y // self.tile_size)
        if (0 <= grid_x < self.current_area.width and
                0 <= grid_y < self.current_area.height):
            self.mouse_position_label.config(text=f"Mouse: ({grid_x}, {grid_y})")
        else:
            self.mouse_position_label.config(text="Mouse: --")

    def on_canvas_leave(self, _event=None):
        self.mouse_position_label.config(text="Mouse: --")

    def on_tile_canvas_click(self, event):
        if self.selected_mode == "enemy":
            canvas_y = self.tile_canvas.canvasy(event.y)
            row_index = int((canvas_y - 10) // 40)
            enemy_ids = list(self.get_enemy_definitions())
            if (
                0 <= row_index < len(enemy_ids)
                and 10 + row_index * 40 <= canvas_y < 42 + row_index * 40
            ):
                self.select_enemy_definition(row_index)
            return

        if self.selected_mode in ("npc", "player"):
            npc_names = self.tile_manager.get_npc_names()
            canvas_y = self.tile_canvas.canvasy(event.y)
            row_index = int((canvas_y - 10) // 40)
            if (
                0 <= row_index < len(npc_names)
                and 10 + row_index * 40 <= canvas_y < 40 + row_index * 40
            ):
                self.selected_tile = npc_names[row_index]
                self.update_tile_display()
                if self.selected_mode == "player":
                    self.get_player_settings()["sprite"] = self.selected_tile
                    self.draw_area()
            return

        clicked = self.tile_canvas.find_closest(event.x, event.y)[0]
        tags = self.tile_canvas.gettags(clicked)
        for tag in tags:
            if tag.startswith("message_"):
                self.edit_game_message(tag[8:])
                break
            if tag.startswith("tile_"):
                self.selected_tile = tag[5:]
                self.update_tile_display()
                break
            elif tag.startswith("obj_"):
                self.selected_tile = tag[4:]
                self.update_tile_display()
                self.load_object_definition_editor()
                self.update_properties_display()
                break
            elif tag.startswith("npc_"):
                self.selected_tile = tag[4:]
                self.update_tile_display()
                if self.selected_mode == "player":
                    self.get_player_settings()["sprite"] = self.selected_tile
                    self.draw_area()
                break
            elif tag.startswith("trigger_"):
                self.selected_tile = tag[8:]  # trigger type (e.g., "teleport")
                self.update_tile_display()
                self.update_properties_display()
                break
    
    def on_mode_change(self):
        previous_mode = getattr(self, "selected_mode", None)
        if previous_mode == "enemy" and not self.save_enemy_definition():
            self.mode_var.set(previous_mode)
            return
        if previous_mode == "trigger" and not self.save_selected_trigger(
            show_error=True, refresh=False
        ):
            self.mode_var.set(previous_mode)
            return

        self.selected_mode = self.mode_var.get()
        if self.selected_mode == "enemy":
            self.refresh_enemy_editor()
        elif self.selected_mode == "trigger":
            self.selected_tile = "teleport"
        elif self.selected_mode == "player":
            player = self.get_player_settings()
            npc_names = self.tile_manager.get_npc_names()
            self.selected_tile = (
                player["sprite"] if player["sprite"] in npc_names
                else (npc_names[0] if npc_names else "fighter_npc")
            )
            player["sprite"] = self.selected_tile
        elif self.selected_mode == "tile" and self.tile_manager.get_tile_names():
            self.selected_tile = list(self.tile_manager.get_tile_names())[0]
        elif self.selected_mode == "object":
            self.selected_tile = (self.tile_manager.get_object_names() or
                                  ["item", "lever", "fountain", "chest", "barrel"])[0]
        elif self.selected_mode == "npc":
            self.selected_tile = (self.tile_manager.get_npc_names() or
                                  ["guard", "merchant", "villager", "wizard", "knight"])[0]
        if hasattr(self, "trigger_editor_frame"):
            if self.selected_mode == "trigger":
                self.tile_walkable_frame.pack_forget()
                self.object_definition_frame.pack_forget()
                self.details_label.pack_forget()
                self.properties_text.pack_forget()
                self.trigger_editor_frame.pack(
                    fill=tk.BOTH, expand=True, padx=5, pady=5
                )
            else:
                self.trigger_editor_frame.pack_forget()
                self.details_label.pack(padx=5, pady=(10, 0))
                self.properties_text.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        if hasattr(self, "player_setup_frame"):
            if self.selected_mode == "player":
                self.tile_walkable_frame.pack_forget()
                self.object_definition_frame.pack_forget()
                if hasattr(self, "player_inventory_frame"):
                    self.player_inventory_frame.pack(
                        before=self.tile_canvas_frame,
                        fill=tk.X,
                        padx=5,
                        pady=(0, 4),
                    )
                self.details_label.pack(padx=5, pady=(10, 0))
                self.properties_text.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
                self.player_setup_frame.pack(
                    before=self.details_label, fill=tk.X, padx=5, pady=5
                )
                self.details_label.pack_forget()
                self.properties_text.pack_forget()
                self.refresh_player_setup()
            else:
                self.player_setup_frame.pack_forget()
                if hasattr(self, "player_inventory_frame"):
                    self.player_inventory_frame.pack_forget()
        if hasattr(self, "enemy_properties_frame"):
            if self.selected_mode == "enemy":
                self.tile_walkable_frame.pack_forget()
                self.object_definition_frame.pack_forget()
                self.trigger_editor_frame.pack_forget()
                self.details_label.pack_forget()
                self.properties_text.pack_forget()
                self.player_setup_frame.pack_forget()
                self.enemy_properties_frame.pack(fill=tk.X, padx=5, pady=5)
                self.enemy_controls_frame.pack(fill=tk.X, padx=5, pady=5)
                self.refresh_enemy_editor()
            else:
                self.enemy_properties_frame.pack_forget()
                self.enemy_controls_frame.pack_forget()
        if hasattr(self, "object_definition_frame"):
            if self.selected_mode == "object":
                self.tile_walkable_frame.pack_forget()
                self.object_definition_frame.pack(
                    before=self.details_label, fill=tk.X, padx=5, pady=5
                )
                self.load_object_definition_editor()
            elif self.selected_mode in ("player", "enemy"):
                self.object_definition_frame.pack_forget()
                self.tile_walkable_frame.pack_forget()
            elif self.selected_mode == "trigger" and not hasattr(
                self, "trigger_editor_frame"
            ):
                self.object_definition_frame.pack_forget()
                self.tile_walkable_frame.pack_forget()
            elif self.selected_mode != "trigger":
                self.object_definition_frame.pack_forget()
                self.tile_walkable_frame.pack(
                    before=self.details_label, fill=tk.X, padx=5, pady=5
                )
        self.update_tile_display()
        if hasattr(self, "trigger_listbox"):
            self.refresh_trigger_editor()
        self.update_properties_display()

    def load_object_definition_editor(self):
        if self.selected_mode != "object":
            return
        definition = self.current_game.get_object_definition(self.selected_tile)
        if hasattr(self, "object_item_type_var"):
            self.object_item_type_var.set(definition["item_type"])
            self.object_weapon_damage_var.set(str(definition["weapon_damage"]))
            if hasattr(self, "item_detail_vars"):
                for key, variable in self.item_detail_vars.items():
                    value = definition[key]
                    variable.set(("yes" if value else "no") if key == "ranged" else str(value))
            self.on_object_item_type_change()
        self.object_gettable_var.set(definition["gettable"])
        self.object_walkable_var.set(definition["walkable"])
        self.object_effect_mode_var.set(definition["effect_mode"])
        for stat, value_var in self.object_effect_vars.items():
            value_var.set(str(definition["effects"].get(stat, 0)))
        self.on_object_gettable_change()
        self._remember_object_form()

    def _remember_object_form(self):
        if hasattr(self, "remember_editor_form"):
            variables = [self.object_gettable_var, self.object_walkable_var, self.object_effect_mode_var,
                         *self.object_effect_vars.values()]
            if hasattr(self, "object_item_type_var"):
                variables += [self.object_item_type_var, self.object_weapon_damage_var]
            variables += list(getattr(self, "item_detail_vars", {}).values())
            self.remember_editor_form("object", variables)

    def on_object_item_type_change(self, _event=None):
        kind = self.object_item_type_var.get()
        if kind not in ("object", "openable"):
            self.object_gettable_var.set(True)
        self.on_object_gettable_change()
        if kind == "weapon":
            self.object_weapon_frame.pack(fill=tk.X, padx=5, pady=3, before=self.object_save_button)
        else:
            self.object_weapon_frame.pack_forget()
        for group, frame in getattr(self, "item_detail_frames", {}).items():
            if group == kind:
                frame.pack(fill=tk.X, padx=5, pady=3, before=self.object_save_button)
            else:
                frame.pack_forget()
        if kind == "consumable":
            self.object_effect_mode_var.set("consumable")
        if kind == "armor" and hasattr(self, "item_detail_vars"):
            variable = self.item_detail_vars["equipment_slot"]
            if variable.get() not in ("head", "offhand"):
                variable.set("head")

    def on_object_gettable_change(self):
        kind = self.object_item_type_var.get() if hasattr(self, "object_item_type_var") else "object"
        if self.object_gettable_var.get() and kind in ("object", "consumable"):
            self.object_effects_frame.pack(fill=tk.X, padx=5, pady=3)
        else:
            self.object_effects_frame.pack_forget()

    def save_object_definition_changes(self):
        object_type = self.selected_tile
        if self.selected_mode != "object":
            return False

        weapon_settings = {}
        if hasattr(self, "object_item_type_var"):
            item_type = self.object_item_type_var.get()
            try:
                weapon_damage = int(self.object_weapon_damage_var.get()) if item_type == "weapon" else 0
            except ValueError:
                messagebox.showerror("Invalid Weapon", "Weapon damage bonus must be a whole number.")
                return False
            if item_type not in ITEM_TYPES or weapon_damage < 0:
                messagebox.showerror("Invalid Weapon", "Choose an item type and a non-negative damage bonus.")
                return False
            weapon_settings = {"item_type": item_type, "weapon_damage": weapon_damage}
            if item_type not in ("object", "openable"):
                self.object_gettable_var.set(True)
            if hasattr(self, "item_detail_vars"):
                try:
                    for key, variable in self.item_detail_vars.items():
                        value = variable.get()
                        weapon_settings[key] = (value == "yes") if key == "ranged" else (
                            int(value) if key in ("armor_bonus", "attack_range", "energy_cost") else value
                        )
                    if item_type == "armor" and not weapon_settings.get("equipment_slot"):
                        weapon_settings["equipment_slot"] = "head"
                    validate_item(weapon_settings)
                except (ValueError, TypeError) as error:
                    messagebox.showerror("Invalid Item", str(error))
                    return False

        if self.object_gettable_var.get():
            try:
                effects = {
                    stat: int(value_var.get())
                    for stat, value_var in self.object_effect_vars.items()
                }
            except ValueError:
                messagebox.showerror("Invalid Effect", "Stat effects must be whole numbers.")
                return False
        else:
            effects = {stat: 0 for stat in self.object_effect_vars}

        self.current_game.object_definitions[object_type] = {
            **self.current_game.object_definitions.get(object_type, {}),
            **weapon_settings,
            "gettable": self.object_gettable_var.get(),
            "walkable": self.object_walkable_var.get(),
            "effect_mode": "consumable" if weapon_settings.get("item_type") == "consumable" else self.object_effect_mode_var.get(),
            "effects": effects,
        }
        self.draw_area()
        self.update_properties_display()
        self._remember_object_form()
        return True

    def get_trigger_type_description(self, trigger_type):
        descriptions = {
            "teleport": "Moves the player to another area.",
            "inventory": "Adds or removes an item from the player's inventory.",
            "player_stats": "Changes a player stat by a signed amount.",
            "funds": "Adds or removes funds. Removal requires sufficient funds.",
            "tile_update": "Changes a tile in the current area.",
            "area_object": "Adds or removes an object on an area map.",
            "game_end": "Ends the game with a win or loss.",
            "show_message": "Displays a message to the player.",
            "custom": "Legacy custom scripts are not supported by the runner.",
        }
        return descriptions.get(trigger_type, "Unknown trigger type.")

    def edit_game_message(self, message_type):
        message_fields = {
            "intro": ("Intro Message", "intro_message"),
            "instructions": ("Help / Instructions Message", "instructions_message"),
            "game_end": ("Game End Message", "game_end_message"),
        }
        if message_type not in message_fields:
            return

        title, field_name = message_fields[message_type]
        dialog = tk.Toplevel(self.root)
        dialog.title(title)
        dialog.geometry("500x350")
        dialog.transient(self.root)

        button_frame = ttk.Frame(dialog)
        button_frame.pack(side=tk.BOTTOM, fill=tk.X, padx=10, pady=(0, 10))
        ttk.Button(button_frame, text="Cancel", command=dialog.destroy).pack(side=tk.RIGHT)

        message_text = tk.Text(dialog, wrap=tk.WORD)
        message_text.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        message_text.insert("1.0", getattr(self.current_game, field_name))

        def save_message():
            setattr(self.current_game, field_name, message_text.get("1.0", tk.END).rstrip("\n"))
            dialog.destroy()

        ttk.Button(button_frame, text="Save", command=save_message).pack(side=tk.RIGHT, padx=(5, 0))
    
    def on_area_name_change(self, *_args):
        self.current_area.name = self.area_name_var.get()

    def on_game_name_change(self, *_args):
        self.current_game.name = self.game_name_var.get()
    
    def on_walkable_change(self):
        if self.selected_mode in ("messages", "editor_help"):
            return

        tile = self.current_area.tiles[self.cursor_y][self.cursor_x]
        value = self.walkable_override_var.get()
        if value == "default":
            tile.walkable_override = None
        elif value == "walkable":
            tile.walkable_override = True
        else:
            tile.walkable_override = False
        self.update_properties_display()
        self.draw_area()
    
    def is_tile_blocked(self, x, y):
        tile = self.current_area.tiles[y][x]
        if not tile.is_walkable(self.tile_manager):
            return True
        
        npc_names = set(self.tile_manager.get_npc_names())
        for obj in self.current_area.objects:
            if obj.x == x and obj.y == y:
                if obj.type in npc_names:
                    if obj.properties.get("walkable", False) is False:
                        return True
                else:
                    walkable = self.current_game.get_object_definition(obj.type)["walkable"]
                    if obj.properties.get("walkable", walkable) is False:
                        return True
        
        return False
    
    def draw_area(self):
        self.canvas.delete("all")
        
        for y in range(self.current_area.height):
            for x in range(self.current_area.width):
                x1, y1 = x * self.tile_size, y * self.tile_size
                tile = self.current_area.tiles[y][x]
                tile_info = self.tile_manager.get_tile_info(tile.type)
                
                if "image" in tile_info:
                    self.canvas.create_image(x1, y1, image=tile_info["image"], anchor=tk.NW)
                else:
                    self.canvas.create_rectangle(x1, y1, x1 + self.tile_size, y1 + self.tile_size, 
                                               fill="lightgray", outline="black")
                
                self.canvas.create_rectangle(x1, y1, x1 + self.tile_size, y1 + self.tile_size, 
                                           outline="gray", width=1)
                
                # Show non-walkable tiles
                if tile.type != "empty" and self.is_tile_blocked(x, y):
                    self.canvas.create_text(x1 + 16, y1 + 16, text="✗", fill="red", 
                                          font=("Arial", 12, "bold"))
        
        # Draw objects and NPCs
        for obj in self.current_area.objects:
            x1, y1 = obj.x * self.tile_size, obj.y * self.tile_size
            enemy_id = obj.properties.get("enemy_id")
            enemy_data = obj.properties.get("enemy_data")
            if enemy_id and hasattr(self, "get_enemy_definitions"):
                enemy_data = self.get_enemy_definitions().get(enemy_id, enemy_data)
            if enemy_data:
                sprite = enemy_data.get("sprite", obj.type)
                enemy_info = self.tile_manager.get_npc_info(sprite)
                if "image" in enemy_info:
                    self.canvas.create_image(
                        x1, y1, image=enemy_info["image"], anchor=tk.NW
                    )
                else:
                    self.canvas.create_rectangle(
                        x1 + 4, y1 + 4, x1 + 28, y1 + 28,
                        fill="#DC143C", outline="black", width=2,
                    )
                self.canvas.create_rectangle(
                    x1 + 1, y1 + 1, x1 + self.tile_size - 1,
                    y1 + self.tile_size - 1, outline="#DC143C", width=2,
                )
                continue
            npc_info = self.tile_manager.get_npc_info(obj.type)
            obj_info = self.tile_manager.get_object_info(obj.type)
            
            if "image" in npc_info:
                self.canvas.create_image(x1, y1, image=npc_info["image"], anchor=tk.NW)
            elif "image" in obj_info:
                self.canvas.create_image(x1, y1, image=obj_info["image"], anchor=tk.NW)
            else:
                x2, y2 = x1 + self.tile_size, y1 + self.tile_size
                if obj.type in ["guard", "merchant", "villager", "wizard", "knight", "enemy", "boss"]:
                    colors = {"guard": "#4169E1", "merchant": "#FFD700", "villager": "#90EE90",
                             "wizard": "#9370DB", "knight": "#C0C0C0", "enemy": "#DC143C", "boss": "#8B0000"}
                    color = colors.get(obj.type, "#FFD700")
                    self.canvas.create_oval(x1 + 4, y1 + 4, x2 - 4, y2 - 4, fill=color, outline="black", width=2)
                    self.canvas.create_text(x1 + 16, y1 + 16, text="N", fill="white", font=("Arial", 8, "bold"))
                else:
                    colors = {"item": "#32CD32", "lever": "#FF4500", "fountain": "#00CED1",
                             "chest": "#8B4513", "barrel": "#654321", "table": "#DEB887"}
                    color = colors.get(obj.type, "#32CD32")
                    self.canvas.create_rectangle(x1 + 4, y1 + 4, x2 - 4, y2 - 4, fill=color, outline="black", width=2)
        
        # Draw triggers with new color system
        trigger_locations = {}
        for trigger in self.current_area.triggers:
            key = (trigger.x, trigger.y)
            if key not in trigger_locations:
                trigger_locations[key] = []
            trigger_locations[key].append(trigger)
        
        for (x, y), triggers in trigger_locations.items():
            x1, y1 = x * self.tile_size, y * self.tile_size
            x2, y2 = x1 + self.tile_size, y1 + self.tile_size
            center_x, center_y = (x1 + x2) / 2, (y1 + y2) / 2
            
            top_trigger = triggers[0]
            if (x, y) == (self.cursor_x, self.cursor_y) and \
                    0 <= self.selected_trigger_index < len(triggers):
                top_trigger = triggers[self.selected_trigger_index]
            color = self.trigger_colors.get(top_trigger.trigger_type, "#CC0000")
            self.canvas.create_polygon(center_x, y1 + 4, x2 - 4, center_y, center_x, y2 - 4, x1 + 4, center_y,
                                     fill=color, outline="black", width=2)
            if len(triggers) > 1:
                marker_number = len(triggers)
                if (x, y) == (self.cursor_x, self.cursor_y):
                    marker_number = self.selected_trigger_index + 1
                number_color = (
                    "black"
                    if top_trigger.trigger_type in ("tile_update", "show_message")
                    else "white"
                )
                self.canvas.create_text(center_x, center_y, text=str(marker_number),
                                      fill=number_color, font=("Arial", 10, "bold"))

        properties = getattr(getattr(self, "current_game", None), "properties", {})
        start_area = properties.get("start_area")
        current_area_filename = (
            os.path.basename(self.current_area_file)
            if getattr(self, "current_area_file", None) else ""
        )
        start_x = properties.get("start_x")
        start_y = properties.get("start_y")
        if (start_area == current_area_filename and
                isinstance(start_x, int) and isinstance(start_y, int) and
                0 <= start_x < self.current_area.width and
                0 <= start_y < self.current_area.height):
            x1, y1 = start_x * self.tile_size, start_y * self.tile_size
            player = properties.get("player", {})
            sprite = player.get("sprite", "")
            player_info = self.tile_manager.get_npc_info(sprite)
            if "image" in player_info:
                self.canvas.create_image(
                    x1, y1, image=player_info["image"], anchor=tk.NW,
                    tags="player_start",
                )
            self.canvas.create_rectangle(
                x1 + 1, y1 + 1, x1 + self.tile_size - 1, y1 + self.tile_size - 1,
                outline="#00FFFF", width=2, tags="player_start",
            )
        
        self.canvas.configure(scrollregion=self.canvas.bbox("all"))
        self.update_cursor_display()
    
    def update_cursor_display(self):
        self.canvas.delete("cursor")
        x1, y1 = self.cursor_x * self.tile_size, self.cursor_y * self.tile_size
        x2, y2 = x1 + self.tile_size, y1 + self.tile_size
        self.canvas.create_rectangle(x1, y1, x2, y2, outline="red", width=3, tags="cursor")
        self.cursor_label.config(text=f"Cursor: ({self.cursor_x}, {self.cursor_y})")
    
    def update_tile_display(self):
        self.tile_canvas.delete("all")
        
        if self.selected_mode == "enemy":
            definitions = self.get_enemy_definitions()
            for index, (enemy_id, definition) in enumerate(definitions.items()):
                y = index * 40 + 10
                sprite_info = self.tile_manager.get_npc_info(
                    definition.get("sprite", "")
                )
                if "image" in sprite_info:
                    self.tile_canvas.create_image(
                        10, y, image=sprite_info["image"], anchor=tk.NW
                    )
                else:
                    self.tile_canvas.create_rectangle(
                        10, y, 40, y + 30, fill="#DC143C", outline="black"
                    )
                self.tile_canvas.create_text(
                    50, y + 15,
                    text=definition.get("name", enemy_id),
                    anchor=tk.W,
                )
                if enemy_id == self.selected_enemy_id:
                    self.tile_canvas.create_rectangle(
                        8, y - 2, 220, y + 32, outline="red", width=2
                    )
        elif self.selected_mode == "tile":
            tiles_per_row = 5
            tile_names = self.tile_manager.get_tile_names()
            for i, tile_name in enumerate(tile_names):
                row, col = i // tiles_per_row, i % tiles_per_row
                x, y = col * 40 + 10, row * 40 + 10
                tile_info = self.tile_manager.get_tile_info(tile_name)
                self.tile_canvas.create_image(x, y, image=tile_info["image"], anchor=tk.NW, tags=f"tile_{tile_name}")
                if tile_name == self.selected_tile:
                    self.tile_canvas.create_rectangle(x-2, y-2, x+34, y+34, outline="red", width=2, tags="selection")
        
        elif self.selected_mode == "npc":
            npc_names = self.tile_manager.get_npc_names() or ["guard", "merchant", "villager", "wizard", "knight"]
            for i, npc_name in enumerate(npc_names):
                y = i * 40 + 10
                npc_info = self.tile_manager.get_npc_info(npc_name)
                if "image" in npc_info:
                    self.tile_canvas.create_image(10, y, image=npc_info["image"], anchor=tk.NW, tags=f"npc_{npc_name}")
                else:
                    colors = {"guard": "#4169E1", "merchant": "#FFD700", "villager": "#90EE90",
                             "wizard": "#9370DB", "knight": "#C0C0C0"}
                    color = colors.get(npc_name, "#FFD700")
                    self.tile_canvas.create_oval(10, y, 40, y + 30, fill=color, outline="black", tags=f"npc_{npc_name}")
                self.tile_canvas.create_text(50, y + 15, text=npc_name.title(), anchor=tk.W)
                if npc_name == self.selected_tile:
                    self.tile_canvas.create_rectangle(8, y-2, 200, y + 32, outline="red", width=2, tags="selection")

        elif self.selected_mode == "player":
            npc_names = self.tile_manager.get_npc_names()
            for i, npc_name in enumerate(npc_names):
                y = i * 40 + 10
                npc_info = self.tile_manager.get_npc_info(npc_name)
                if "image" in npc_info:
                    self.tile_canvas.create_image(
                        10, y, image=npc_info["image"], anchor=tk.NW,
                        tags=f"npc_{npc_name}",
                    )
                self.tile_canvas.create_text(
                    50, y + 15, text=npc_name.replace("_", " ").title(), anchor=tk.W,
                    tags=f"npc_{npc_name}",
                )
                if npc_name == self.selected_tile:
                    self.tile_canvas.create_rectangle(
                        8, y - 2, 200, y + 32, outline="red", width=2,
                        tags="selection",
                    )
        
        elif self.selected_mode == "object":
            obj_names = self.tile_manager.get_object_names() or ["item", "lever", "fountain", "chest", "barrel"]
            for i, obj_name in enumerate(obj_names):
                y = i * 40 + 10
                obj_info = self.tile_manager.get_object_info(obj_name)
                if "image" in obj_info:
                    self.tile_canvas.create_image(10, y, image=obj_info["image"], anchor=tk.NW, tags=f"obj_{obj_name}")
                else:
                    colors = {"item": "#32CD32", "lever": "#FF4500", "fountain": "#00CED1",
                             "chest": "#8B4513", "barrel": "#654321"}
                    color = colors.get(obj_name, "#32CD32")
                    self.tile_canvas.create_rectangle(10, y, 40, y + 30, fill=color, outline="black", tags=f"obj_{obj_name}")
                self.tile_canvas.create_text(50, y + 15, text=obj_info.get("display_name", obj_name.replace("_", " ").title()), anchor=tk.W)
                if obj_name == self.selected_tile:
                    self.tile_canvas.create_rectangle(8, y-2, 200, y + 32, outline="red", width=2, tags="selection")
        
        elif self.selected_mode == "trigger":
            trigger_types = ["teleport", "inventory", "player_stats", "funds", "tile_update", "area_object", "game_end", "show_message"]
            trigger_names = {
                "teleport": "Teleport",
                "inventory": "Inventory",
                "player_stats": "Player Stats",
                "funds": "Funds",
                "tile_update": "Tile Update",
                "area_object": "Area Object", 
                "game_end": "Game End",
                "show_message": "Show Message",
                "custom": "Custom Script"
            }
            
            for i, trigger_type in enumerate(trigger_types):
                y = i * 40 + 10
                color = self.trigger_colors[trigger_type]
                
                # Draw colored diamond preview
                center_x, center_y = 25, y + 20
                self.tile_canvas.create_polygon(center_x, y + 5, 40, center_y, center_x, y + 35, 10, center_y, 
                                              fill=color, outline="black", tags=f"trigger_{trigger_type}")
                self.tile_canvas.create_text(50, y + 20, text=trigger_names[trigger_type], anchor=tk.W)
                
                if trigger_type == self.selected_tile:
                    self.tile_canvas.create_rectangle(8, y-2, 200, y + 32, outline="red", width=2, tags="selection")

        elif self.selected_mode == "messages":
            message_entries = [
                ("intro", "Intro Message"),
                ("instructions", "Help / Instructions Message"),
                ("game_end", "Game End Message"),
            ]
            for i, (message_type, label) in enumerate(message_entries):
                y = i * 55 + 15
                self.tile_canvas.create_text(
                    10,
                    y,
                    text=label,
                    anchor=tk.NW,
                    width=190,
                    tags=f"message_{message_type}",
                )
                self.tile_canvas.create_text(
                    10,
                    y + 22,
                    text="Click to edit",
                    anchor=tk.NW,
                    fill="gray",
                    tags=f"message_{message_type}",
                )

        elif self.selected_mode == "editor_help":
            help_text = (
                "EDITOR HELP\n\n"
                "Tiles, Objects, and NPCs:\n"
                "Choose an item, then use Space or right-click to place it at the cursor/map cell.\n\n"
                "Enemies:\n"
                "Add and select enemy types in the left panel, edit their stats on the right, "
                "then press Space to place the selected enemy at the cursor. "
                "Use Delete to remove an enemy from the cursor tile.\n\n"
                "Triggers:\n"
                "Choose a trigger and use Space or right-click to add it at a map cell. "
                "Select stacked triggers "
                "in the right panel (or use 1-9 and 0 for the first ten). "
                "Edit fields in the right panel; Save commits them, and Delete "
                "removes the selected trigger.\n\n"
                "Map navigation (in editing modes):\n"
                "Click a map cell or use the arrow keys to move the cursor. "
                "Messages and Editor Help modes pause map editing.\n\n"
                "Area tools:\n"
                "Use the Area and Tools menus to save, resize, crop, and manage assets."
            )
            self.tile_canvas.create_text(
                10,
                10,
                text=help_text,
                anchor=tk.NW,
                width=190,
                tags="editor_help",
            )
        
        self.tile_canvas.configure(scrollregion=self.tile_canvas.bbox("all"))
        if hasattr(self, 'selected_tile_label'):
            if self.selected_mode == "messages":
                self.selected_tile_label.config(text="Choose a message to edit")
            elif self.selected_mode == "editor_help":
                self.selected_tile_label.config(text="Editor help")
            else:
                self.selected_tile_label.config(text=f"Selected: {self.selected_tile}")
    
    def update_properties_display(self):
        self.properties_text.configure(state='normal')
        self.properties_text.delete(1.0, tk.END)
        
        tile = self.current_area.tiles[self.cursor_y][self.cursor_x]
        objects_here = [obj for obj in self.current_area.objects if obj.x == self.cursor_x and obj.y == self.cursor_y]
        triggers_here = [trig for trig in self.current_area.triggers if trig.x == self.cursor_x and trig.y == self.cursor_y]
        
        info = ""
        if triggers_here and 0 <= self.selected_trigger_index < len(triggers_here):
            selected_trigger = triggers_here[self.selected_trigger_index]
            info += f"Selected trigger: {selected_trigger.get_description()}\n\n"
        elif self.selected_mode == "trigger":
            info += (
                f"Trigger type: {self.get_trigger_type_description(self.selected_tile)}\n\n"
            )
        elif self.selected_mode == "object":
            definition = self.current_game.get_object_definition(self.selected_tile)
            info += f"Object definition: {self.selected_tile}\n"
            info += f"Gettable: {definition['gettable']}\n"
            info += f"Walkable: {definition['walkable']}\n"
            info += f"Item type: {definition['item_type']}\n"
            if definition["item_type"] == "weapon":
                info += f"Weapon damage bonus: +{definition['weapon_damage']}\n"
                if definition["ranged"]:
                    info += f"Ranged: {definition['attack_range']} tiles; energy cost {definition['energy_cost']}\n"
            elif definition["item_type"] == "armor":
                info += f"Armor: +{definition['armor_bonus']} ({definition['equipment_slot']})\n"
            if definition["gettable"]:
                info += f"Effect mode: {definition['effect_mode']}\n"
                info += f"Effects: {self._format_object_effects(definition['effects'])}\n\n"
            else:
                info += "Inventory effects: none (object is not gettable)\n\n"

        info += f"Position: ({self.cursor_x}, {self.cursor_y})\n\n"
        tile_info = self.tile_manager.get_tile_info(tile.type)
        global_walkable = self.tile_manager.get_default_walkable(tile.type)
        
        info += f"Tile: {tile_info.get('display_name', tile.type)}\n"
        info += f"Walkable: {tile.is_walkable(self.tile_manager)}\n\n"
        
        self.global_walkable_label.config(text=f"Default: {global_walkable}")
        if tile.walkable_override is None:
            self.walkable_override_var.set("default")
        elif tile.walkable_override:
            self.walkable_override_var.set("walkable")
        else:
            self.walkable_override_var.set("not_walkable")
        
        if objects_here:
            for obj in objects_here:
                info += f"Object: {obj.type}\n"
                if obj.type not in set(self.tile_manager.get_npc_names()):
                    definition = self.current_game.get_object_definition(obj.type)
                    info += f"  Gettable: {definition['gettable']}, Walkable: {definition['walkable']}\n"
                    if definition["gettable"]:
                        info += (
                            f"  Effect mode: {definition['effect_mode']}, "
                            f"Effects: {self._format_object_effects(definition['effects'])}\n"
                        )
        
        if triggers_here:
            info += f"Triggers: ({len(triggers_here)})\n"
            for i, trigger in enumerate(triggers_here):
                selected_marker = "● " if i == self.selected_trigger_index else "  "
                info += f"{selected_marker}{i+1}. {trigger.name} ({trigger.get_description()})\n"
            info += "\nSelect a trigger in the right panel or use number keys 1-9, 0\n"
        
        self.properties_text.insert(1.0, info)
        self.properties_text.configure(state='disabled')

    @staticmethod
    def _format_object_effects(effects):
        active_effects = [
            f"{stat} {value:+d}"
            for stat, value in effects.items()
            if value
        ]
        return ", ".join(active_effects) if active_effects else "none"

    def _triggers_at_cursor(self):
        return [
            trigger for trigger in self.current_area.triggers
            if trigger.x == self.cursor_x and trigger.y == self.cursor_y
        ]

    def add_trigger_at_cursor(self):
        if self.selected_mode != "trigger":
            self.mode_var.set("trigger")
            self.on_mode_change()
        self.place_tile()

    def cycle_selected_trigger(self, direction):
        triggers_here = self._triggers_at_cursor()
        if triggers_here:
            next_index = (self.selected_trigger_index + direction) % len(triggers_here)
            self.select_trigger_index(next_index)

    def on_trigger_list_select(self, _event=None):
        if getattr(self, "_refreshing_trigger_list", False):
            return
        selection = self.trigger_listbox.curselection()
        if selection and not self.select_trigger_index(selection[0]):
            self.trigger_listbox.selection_clear(0, tk.END)
            self.trigger_listbox.selection_set(self.selected_trigger_index)

    def refresh_trigger_editor(self):
        if not hasattr(self, "trigger_listbox"):
            return

        triggers_here = self._triggers_at_cursor()
        self.selected_trigger_index = min(
            self.selected_trigger_index, max(0, len(triggers_here) - 1)
        )
        self._refreshing_trigger_list = True
        self.trigger_listbox.delete(0, tk.END)
        for index, trigger in enumerate(triggers_here):
            label = f"{index + 1}. {trigger.name} - {trigger.trigger_type.replace('_', ' ').title()}"
            if trigger.enemy_attached:
                label += " [Enemy attached]"
            self.trigger_listbox.insert(tk.END, label)
            self.trigger_listbox.itemconfig(
                index,
                foreground=self.trigger_colors.get(trigger.trigger_type, "#CC0000"),
            )
        if triggers_here:
            self.trigger_listbox.selection_set(self.selected_trigger_index)
            self.trigger_listbox.activate(self.selected_trigger_index)
            self.trigger_listbox.see(self.selected_trigger_index)
        self._refreshing_trigger_list = False

        for child in self.trigger_form_frame.winfo_children():
            child.destroy()
        self._trigger_editor_vars = {}
        self._trigger_editor_tile_labels = {}
        if triggers_here:
            self._build_trigger_editor(triggers_here[self.selected_trigger_index])
        else:
            ttk.Label(
                self.trigger_form_frame,
                text="Select a trigger tool, then click the map or Add.",
                wraplength=245,
            ).pack(anchor=tk.W, pady=5)

    def move_selected_trigger(self, direction):
        if not self.save_selected_trigger(refresh=False):
            return False
        positions = [index for index, trigger in enumerate(self.current_area.triggers)
                     if (trigger.x, trigger.y) == (self.cursor_x, self.cursor_y)]
        selected = self.selected_trigger_index
        target = selected + direction
        if not (0 <= selected < len(positions) and 0 <= target < len(positions)):
            return False
        first, second = positions[selected], positions[target]
        triggers = self.current_area.triggers
        triggers[first], triggers[second] = triggers[second], triggers[first]
        self.selected_trigger_index = target
        self.refresh_trigger_editor()
        self.draw_area()
        self.update_properties_display()
        return True

    def _change_trigger_editor_type(self, trigger, trigger_type, name):
        trigger_type = self._trigger_editor_type_labels.get(trigger_type, trigger_type)
        if trigger_type == getattr(self, "_trigger_editor_draft_type", trigger.trigger_type):
            return
        charge_variable = self._trigger_editor_vars.get("charges")
        charges = charge_variable.get() if charge_variable is not None else trigger_charges(trigger.parameters)
        attachment_var = self._trigger_editor_vars.get("enemy_attached")
        attachment = (self._trigger_editor_enemy_labels.get(attachment_var.get(), "")
                      if attachment_var is not None else trigger.enemy_attached)
        for child in self.trigger_form_frame.winfo_children():
            child.destroy()
        self._trigger_editor_vars = {}
        self._trigger_editor_tile_labels = {}
        self._build_trigger_editor(
            trigger, trigger_type=trigger_type, parameters={"charges": charges}, name=name, enemy_attached=attachment
        )

    def _build_trigger_editor(self, trigger, trigger_type=None, parameters=None, name=None, enemy_attached=None):
        form = self.trigger_form_frame
        self._trigger_editor_trigger = trigger
        trigger_type = trigger_type or trigger.trigger_type
        self._trigger_editor_draft_type = trigger_type
        params = trigger.parameters if parameters is None else parameters
        trigger_types = (
            "teleport",
            "inventory",
            "player_stats",
            "funds",
            "tile_update",
            "area_object",
            "game_end",
            "show_message",
        )
        self._trigger_editor_type_labels = {
            trigger_type.replace("_", " ").title(): trigger_type
            for trigger_type in trigger_types
        }
        trigger_type_var = tk.StringVar(
            value="Custom (unsupported)" if trigger_type == "custom" else trigger_type.replace("_", " ").title()
        )
        self._trigger_editor_vars["trigger_type"] = trigger_type_var
        type_row = ttk.Frame(form)
        type_row.pack(fill=tk.X, pady=2)
        ttk.Label(type_row, text="Type:", width=10).pack(side=tk.LEFT)
        type_combo = ttk.Combobox(
            type_row,
            textvariable=trigger_type_var,
            values=tuple(self._trigger_editor_type_labels),
            state="readonly",
        )
        type_combo.pack(side=tk.LEFT, fill=tk.X, expand=True)
        type_combo.bind(
            "<<ComboboxSelected>>",
            lambda _event: self._change_trigger_editor_type(
                trigger, trigger_type_var.get(), name_var.get()
            ),
        )

        name_var = tk.StringVar(value=trigger.name if name is None else name)
        self._trigger_editor_vars["name"] = name_var
        name_row = ttk.Frame(form)
        name_row.pack(fill=tk.X, pady=2)
        ttk.Label(name_row, text="Name:", width=10).pack(side=tk.LEFT)
        ttk.Entry(name_row, textvariable=name_var).pack(side=tk.LEFT, fill=tk.X, expand=True)

        def add_entry(key, label, value="", width=16):
            row = ttk.Frame(form)
            row.pack(fill=tk.X, pady=2)
            ttk.Label(row, text=label, width=10).pack(side=tk.LEFT)
            variable = tk.StringVar(value=str(value))
            ttk.Entry(row, textvariable=variable, width=width).pack(
                side=tk.LEFT, fill=tk.X, expand=True
            )
            self._trigger_editor_vars[key] = variable
            return variable

        def add_combo(key, label, values, value="", state="readonly", label_width=10):
            row = ttk.Frame(form)
            row.pack(fill=tk.X, pady=2)
            ttk.Label(row, text=label, width=label_width).pack(side=tk.LEFT)
            variable = tk.StringVar(value=value)
            ttk.Combobox(
                row, textvariable=variable, values=values, state=state, width=16
            ).pack(side=tk.LEFT, fill=tk.X, expand=True)
            self._trigger_editor_vars[key] = variable
            return variable

        def add_text(key, label, value="", height=4):
            ttk.Label(form, text=label).pack(anchor=tk.W, pady=(4, 0))
            text = tk.Text(form, height=height, wrap=tk.WORD)
            text.pack(fill=tk.X, expand=False)
            text.insert("1.0", value)
            self._trigger_editor_vars[key] = text
            return text

        def add_coordinate_picker(x_var, y_var, destination_area_var=None):
            def start_pick():
                destination_area = (
                    destination_area_var.get()
                    if destination_area_var is not None
                    else None
                )
                self._begin_trigger_position_pick(
                    x_var, y_var, destination_area
                )

            ttk.Button(form, text="Pick coordinates on map", command=start_pick).pack(
                anchor=tk.W, pady=3
            )

        if trigger_type == "teleport":
            area_names = [os.path.splitext(area)[0] for area in self.current_game.areas]
            destination_area_var = add_combo(
                "area", "Area:", area_names, params.get("area", "")
            )
            x_var = add_entry("x", "Target X:", params.get("x", 0))
            y_var = add_entry("y", "Target Y:", params.get("y", 0))
            add_coordinate_picker(x_var, y_var, destination_area_var)
            ttk.Label(form, text="Save destination areas before linking teleports.", wraplength=245).pack(anchor=tk.W, pady=3)
        elif trigger_type == "funds":
            add_combo("action", "Action:", ("add", "remove"), params.get("action", "add"))
            add_entry("amount", "Amount ($):", params.get("amount", 1))
            ttk.Label(form, text="Use a positive whole amount. Remove fails if funds are insufficient: no money or charge is spent, and later triggers on this tile stop.", wraplength=245).pack(anchor=tk.W, pady=4)
        elif trigger_type == "player_stats":
            stats = [stat for stat in PLAYER_STAT_CHANGES if stat != "gold"]
            if params.get("stat") == "gold":
                stats.append("gold")  # Existing games remain editable; new money triggers use Funds.
            add_combo("stat", "Stat:", stats, params.get("stat", "health"))
            add_entry("amount", "Change (+/-):", params.get("amount", 0))
            ttk.Label(form, text="Use +5 to increase or -5 to decrease. Health and energy stay within their maximums. Zero health ends the game.", wraplength=245).pack(anchor=tk.W, pady=4)
        elif trigger_type == "inventory":
            items = [""] + sorted(set(self.tile_manager.get_object_names())
                                    | set(self.current_game.used_objects)
                                    | set(self.current_game.object_definitions)
                                    | {value for key in ("add", "remove") if (value := params.get(key, ""))})
            add_combo("add", "Add item:", items, params.get("add", ""))
            add_combo("remove", "Remove item:", items, params.get("remove", ""))
            ttk.Label(form, text="Changes inventory only. Use a separate Area Object trigger to add/remove the map object.", wraplength=245).pack(anchor=tk.W, pady=4)
        elif trigger_type == "tile_update":
            x_var = add_entry("x", "Target X:", params.get("x", 0))
            y_var = add_entry("y", "Target Y:", params.get("y", 0))
            tile_name = params.get("tile", "")
            tile_values = {}
            for name in self.tile_manager.get_tile_names():
                display = self.tile_manager.get_tile_info(name).get("display_name", name)
                label = display if display not in tile_values else f"{display} ({name})"
                tile_values[label] = name
            if tile_name and tile_name not in tile_values.values():
                tile_values[tile_name] = tile_name
            selected_label = next(
                (label for label, name in tile_values.items() if name == tile_name), ""
            )
            add_combo("tile", "Change to:", list(tile_values), selected_label)
            self._trigger_editor_tile_labels = tile_values
            current_tile_label = ttk.Label(form, text="")
            current_tile_label.pack(anchor=tk.W, pady=2)

            def update_current_tile(*_args):
                try:
                    target_x, target_y = int(x_var.get()), int(y_var.get())
                except ValueError:
                    current_tile_label.config(text="Current tile: invalid coordinates")
                    return
                if not (0 <= target_x < self.current_area.width and
                        0 <= target_y < self.current_area.height):
                    current_tile_label.config(text="Current tile: outside this area")
                    return
                current_name = self.current_area.tiles[target_y][target_x].type
                display_name = self.tile_manager.get_tile_info(current_name).get(
                    "display_name", current_name
                )
                current_tile_label.config(text=f"Current tile: {display_name}")

            x_var.trace_add("write", update_current_tile)
            y_var.trace_add("write", update_current_tile)
            update_current_tile()
            ttk.Label(
                form,
                text="Click a map tile to set the target coordinates.",
                wraplength=245,
            ).pack(anchor=tk.W, pady=3)
            walkable_var = tk.BooleanVar(value=params.get("walkable", True))
            ttk.Checkbutton(form, text="Walkable", variable=walkable_var).pack(anchor=tk.W)
            self._trigger_editor_vars["walkable"] = walkable_var
        elif trigger_type == "area_object":
            area_names = [""] + [os.path.splitext(area)[0] for area in self.current_game.areas]
            destination = add_combo("area", "Area:", area_names, params.get("area", ""))
            add_combo("action", "Action:", ("add", "remove"), params.get("action", "add"))
            objects = sorted(set(self.tile_manager.get_object_names())
                             | set(self.current_game.used_objects)
                             | {value for value in (params.get("object", ""),) if value})
            add_combo("object", "Object:", objects, params.get("object", ""))
            x_var = add_entry("x", "Target X:", params.get("x", trigger.x))
            y_var = add_entry("y", "Target Y:", params.get("y", trigger.y))
            add_coordinate_picker(x_var, y_var, destination)
            ttk.Label(form, text="Blank area means this area. Only the matching object at the target coordinates changes.", wraplength=245).pack(anchor=tk.W, pady=4)
        elif trigger_type == "game_end":
            add_combo("win_lose", "Result:", ("win", "lose"), params.get("win_lose", "win"))
            add_text("message", "Message:", params.get("message", ""), height=3)
        elif trigger_type == "show_message":
            add_text("message", "Message:", params.get("message", ""), height=5)
        elif trigger_type == "custom":
            ttk.Label(form, text="This legacy custom trigger is not supported by the runner. Choose a supported trigger type above or delete it.", wraplength=245).pack(anchor=tk.W, pady=4)

        ensure_enemy_instance_ids(self.current_area)
        enemy_labels = {"(none — walk onto tile)": ""}
        definitions = self.current_game.properties.get("enemies", {})
        for obj in self.current_area.objects:
            identity = obj.properties.get("enemy_instance_id")
            if not identity:
                continue
            definition = definitions.get(obj.properties.get("enemy_id"), obj.properties.get("enemy_data", {}))
            label = f"{definition.get('name', obj.type)} at ({obj.x}, {obj.y})"
            enemy_labels[label] = identity
        attached = trigger.enemy_attached if enemy_attached is None else enemy_attached
        if attached and attached not in enemy_labels.values():
            enemy_labels["Missing enemy — select another"] = attached
        selected_enemy = next(label for label, identity in enemy_labels.items() if identity == attached)
        self._trigger_editor_enemy_labels = enemy_labels
        add_combo("enemy_attached", "Enemy attached:", list(enemy_labels), selected_enemy, label_width=15)
        ttk.Label(form, text="Attached triggers fire when that enemy is defeated. Their map position stays fixed.", wraplength=245).pack(anchor=tk.W, pady=3)

        add_entry("charges", "Charges:", params.get("charges", 1 if params.get("once", False) else 0))
        ttk.Label(form, text="0 = unlimited; 1 = the first successful entry only. Failed actions do not spend charges. Remaining charges are saved with your run.", wraplength=245).pack(anchor=tk.W, pady=3)
        ttk.Label(form, text="Triggers run in list order. A failed trigger stops the remaining actions on this tile.", wraplength=245).pack(anchor=tk.W, pady=3)

        if hasattr(self, "remember_editor_form"):
            self.remember_editor_form("trigger", self._trigger_editor_vars.values())

    def save_selected_trigger(self, show_error=True, refresh=True):
        if getattr(self, "selected_mode", "trigger") != "trigger":
            return True
        trigger = getattr(self, "_trigger_editor_trigger", None)
        variables = getattr(self, "_trigger_editor_vars", {})
        if trigger is None or not variables:
            return True

        parameters = {}
        for name, variable in variables.items():
            if name in ("name", "trigger_type", "enemy_attached"):
                continue
            if isinstance(variable, tk.Text):
                parameters[name] = variable.get("1.0", tk.END).rstrip("\n")
            elif isinstance(variable, tk.BooleanVar):
                parameters[name] = variable.get()
            else:
                value = variable.get()
                if name in ("x", "y", "amount", "charges"):
                    try:
                        value = int(value)
                    except ValueError:
                        if show_error:
                            messagebox.showerror(
                                "Invalid Trigger Value",
                                f"{name.replace('_', ' ').title()} must be a whole number.",
                            )
                        return False
                parameters[name] = value

        trigger_type = self._trigger_editor_type_labels.get(
            variables["trigger_type"].get()
        )
        if (trigger_type is None and trigger.trigger_type == "custom"
                and variables["trigger_type"].get() == "Custom (unsupported)"):
            trigger_type = "custom"
            parameters = {**trigger.parameters, **parameters}
        if trigger_type is None:
            if show_error:
                messagebox.showerror("Invalid Trigger Type", "Choose a valid trigger type.")
            return False
        if trigger_type == "funds":
            try:
                funds_delta(parameters)
            except ValueError as error:
                if show_error:
                    messagebox.showerror("Invalid Funds", str(error))
                return False
        if trigger_type == "player_stats" and parameters.get("stat") not in PLAYER_STAT_CHANGES:
            if show_error:
                messagebox.showerror("Invalid Stat", "Choose a player stat.")
            return False
        if trigger_type == "tile_update":
            selected_tile = self._trigger_editor_tile_labels.get(
                parameters.get("tile", "")
            )
            if not selected_tile:
                if show_error:
                    messagebox.showerror(
                        "Select a Tile", "Choose the tile to change the target to."
                    )
                return False
            parameters["tile"] = selected_tile

        try:
            trigger_charges(parameters)
        except ValueError as error:
            if show_error:
                messagebox.showerror("Invalid Charges", str(error))
            return False
        coordinate_error = self._trigger_coordinate_error(trigger_type, parameters)
        if coordinate_error:
            if show_error:
                messagebox.showerror("Invalid Coordinates", coordinate_error)
            return False

        if "enemy_attached" in variables:
            attached = self._trigger_editor_enemy_labels.get(variables["enemy_attached"].get())
            if attached is None:
                if show_error:
                    messagebox.showerror("Invalid Enemy", "Choose an attached enemy or no enemy.")
                return False
            if attached != trigger.enemy_attached:
                trigger.enemy_attached = attached
                trigger.enemy_defeated = trigger.enemy_pending = False
        trigger.name = variables["name"].get()
        trigger.trigger_type = trigger_type
        trigger.parameters = parameters
        if hasattr(self, "remember_editor_form"):
            self.remember_editor_form("trigger", variables.values())
        if refresh:
            self.refresh_trigger_editor()
            self.update_properties_display()
            self.draw_area()
        return True

    def delete_selected_trigger(self, confirm=False):
        triggers_here = self._triggers_at_cursor()
        if not triggers_here or not 0 <= self.selected_trigger_index < len(triggers_here):
            return False
        if confirm and not messagebox.askyesno(
            "Delete Trigger", "Delete the selected trigger?"
        ):
            return False

        trigger = triggers_here[self.selected_trigger_index]
        self.current_area.triggers.remove(trigger)
        remaining = self._triggers_at_cursor()
        self.selected_trigger_index = min(
            self.selected_trigger_index, max(0, len(remaining) - 1)
        )
        self._trigger_editor_trigger = None
        self._trigger_editor_vars = {}
        self.refresh_trigger_editor()
        self.update_properties_display()
        self.draw_area()
        return True

    def _trigger_coordinate_error(self, trigger_type, parameters):
        if trigger_type == "area_object" and not parameters.get("area"):
            x, y = parameters["x"], parameters["y"]
            if not (0 <= x < self.current_area.width and 0 <= y < self.current_area.height):
                return "Object coordinates must be within this area."
            return None
        if trigger_type in ("teleport", "area_object"):
            selected_area = parameters.get("area", "")
            area_filename = next(
                (area for area in self.current_game.areas
                 if area == selected_area or os.path.splitext(os.path.basename(area))[0] == selected_area),
                None
            )
            if not area_filename:
                return "Select a destination area that belongs to this game."
            area_path = os.path.join(
                project_root(), "areas", area_filename
            )
            if (self.current_area_file and
                    os.path.realpath(self.current_area_file) == os.path.realpath(area_path)):
                destination_width = self.current_area.width
                destination_height = self.current_area.height
            else:
                try:
                    with open(area_path, 'r') as f:
                        destination_area = json.load(f)
                    destination_width = int(destination_area["width"])
                    destination_height = int(destination_area["height"])
                except FileNotFoundError:
                    if trigger_type == "teleport":
                        return "Save the destination area before linking a teleport to it."
                    return "Save the destination area before targeting it with this trigger."
                except (OSError, KeyError, TypeError, ValueError) as e:
                    return f"Could not read destination area dimensions: {e}"
        elif trigger_type == "tile_update":
            destination_width = self.current_area.width
            destination_height = self.current_area.height
        else:
            return None
        x, y = parameters["x"], parameters["y"]
        if not (0 <= x < destination_width and 0 <= y < destination_height):
            return (
                "Coordinates must be within the destination area "
                f"(X: 0-{destination_width - 1}, Y: 0-{destination_height - 1})."
            )
        return None
