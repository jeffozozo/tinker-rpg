from item_rules import ITEM_TYPES, compatible_slot, validate_item
"""
Updated editor_methods.py with enhanced trigger system
"""

import tkinter as tk
from tkinter import ttk, filedialog, messagebox
import json
import os
from dataclasses import asdict
from copy import deepcopy
from uuid import uuid4

from data_classes import MAX_PLAYER_INVENTORY_SLOTS, PLAYER_STAT_CHANGES, trigger_charges, funds_delta, ensure_enemy_instance_ids
from project_paths import project_root
from trigger_library import definitions_for, resolve_trigger, validate_control

class EditorMethods:
    """Mixin class containing all editor interaction methods"""
    
    def __init__(self):
        # Add trigger selection tracking
        self.selected_trigger_index = 0
        self.trigger_colors = {
            "teleport": "#0066CC",      # Blue
            "funds": "#B8860B",
            "trigger_control": "#708090",
            "enemy_placement": "#B22222",
            "named_trigger": "#406080",
            "player_stats": "#B2498A",
            "inventory": "#009900",     # Green
            "tile_update": "#FFCC00",   # Yellow
            "area_object": "#FF6600",   # Orange
            "game_end": "#9900CC",      # Purple
            "play_sound": "#8B6F47",
            "show_message": "#00CCCC",   # Cyan
            "custom": "#CC0000"         # Red
        }

    def get_player_settings(self):
        properties = self.current_game.properties
        player = properties.setdefault("player", {})
        player.setdefault("sprite", "fighter_npc")
        player.setdefault("starting_inventory", [])
        defaults = {
            "starting_health": 20,
            "max_health": 20,
            "starting_energy": 0,
            "max_energy": 0,
            "strength": 1,
            "intelligence": 1,
            "gold": 0,
        }
        stats = player.setdefault("stats", {})
        for key, value in defaults.items():
            stats.setdefault(key, value)
        properties.setdefault("start_area", "")
        properties.setdefault("start_x", 0)
        properties.setdefault("start_y", 0)
        return player

    def setup_player_inventory(self, parent):
        self.player_inventory_frame = ttk.LabelFrame(
            parent, text=f"Starting Inventory ({MAX_PLAYER_INVENTORY_SLOTS} slots)"
        )
        ttk.Label(
            self.player_inventory_frame,
            text="Mark objects Gettable to add them here.",
        ).pack(anchor=tk.W, padx=4, pady=(3, 1))
        self.player_inventory_vars = []
        self.player_inventory_selectors = []
        for index in range(MAX_PLAYER_INVENTORY_SLOTS):
            row = ttk.Frame(self.player_inventory_frame)
            row.pack(fill=tk.X, padx=4, pady=1)
            ttk.Label(row, text=f"{index + 1}:", width=3).pack(side=tk.LEFT)
            variable = tk.StringVar()
            selector = ttk.Combobox(
                row, textvariable=variable, state="readonly", width=19
            )
            selector.pack(side=tk.LEFT, fill=tk.X, expand=True)
            self.player_inventory_vars.append(variable)
            self.player_inventory_selectors.append(selector)
        ttk.Button(
            self.player_inventory_frame,
            text="Clear Starting Inventory",
            command=self.clear_player_inventory,
        ).pack(fill=tk.X, padx=4, pady=(3, 4))
        self.player_inventory_frame.pack_forget()

    def clear_player_inventory(self):
        for variable in getattr(self, "player_inventory_vars", []):
            variable.set("")

    def refresh_player_inventory(self):
        variables = getattr(self, "player_inventory_vars", [])
        if not variables:
            return
        player = self.get_player_settings()
        inventory = player.get("starting_inventory", [])
        if not isinstance(inventory, list):
            inventory = []
        available_items = self._available_inventory_items()
        for item in inventory:
            if isinstance(item, str) and item and item not in available_items:
                available_items.append(item)
        choices = [""] + available_items
        for selector, variable, index in zip(
            self.player_inventory_selectors, variables, range(len(variables))
        ):
            selector.configure(values=choices)
            item = inventory[index] if index < len(inventory) else ""
            variable.set(item if isinstance(item, str) else "")

    def _available_inventory_items(self):
        return sorted(
            item for item in self.tile_manager.get_object_names()
            if self.current_game.get_object_definition(item).get("gettable")
        )

    def _player_start_area_text(self):
        start_area = self.current_game.properties.get("start_area")
        return f"Start area: {start_area or 'Not set'}"

    def _player_start_position_text(self):
        properties = self.current_game.properties
        return f"Start position: ({properties.get('start_x', 0)}, {properties.get('start_y', 0)})"

    def refresh_player_setup(self):
        player = self.get_player_settings()
        if hasattr(self, "player_start_area_label"):
            self.player_start_area_label.config(text=self._player_start_area_text())
            self.player_start_position_label.config(
                text=self._player_start_position_text()
            )
        for key, variable in getattr(self, "player_stat_vars", {}).items():
            variable.set(str(player["stats"][key]))
        self.refresh_player_inventory()
        if hasattr(self, "remember_editor_form"):
            self.remember_editor_form("player", [*getattr(self, "player_stat_vars", {}).values(),
                                                 *getattr(self, "player_inventory_vars", [])])

    def save_player_setup(self):
        player = self.get_player_settings()
        try:
            stats = {
                key: int(variable.get())
                for key, variable in self.player_stat_vars.items()
            }
        except ValueError:
            messagebox.showerror("Invalid Player Settings", "Player stats must be whole numbers.")
            return False
        if any(value < 0 for value in stats.values()) or stats["max_health"] < 1:
            messagebox.showerror(
                "Invalid Player Settings",
                "Stats cannot be negative, and maximum health must be at least 1.",
            )
            return False
        if stats["starting_health"] < 1:
            messagebox.showerror(
                "Invalid Player Settings",
                "Starting health must be at least 1.",
            )
            return False
        if stats["starting_health"] > stats["max_health"]:
            messagebox.showerror(
                "Invalid Player Settings",
                "Starting health cannot exceed maximum health.",
            )
            return False
        if stats["starting_energy"] > stats["max_energy"]:
            messagebox.showerror(
                "Invalid Player Settings",
                "Starting energy cannot exceed maximum energy.",
            )
            return False
        inventory_vars = getattr(self, "player_inventory_vars", None)
        if inventory_vars is not None:
            inventory = [
                variable.get().strip() for variable in inventory_vars
            ]
            if len(inventory) > MAX_PLAYER_INVENTORY_SLOTS:
                messagebox.showerror(
                    "Invalid Player Inventory",
                    f"Starting inventory can contain at most {MAX_PLAYER_INVENTORY_SLOTS} slots.",
                )
                return False
            old_inventory = player.get("starting_inventory", [])
            old_items = (
                {item for item in old_inventory if isinstance(item, str)}
                if isinstance(old_inventory, list)
                else set()
            )
            available_items = set(self._available_inventory_items()) | old_items
            invalid_items = sorted(
                item for item in inventory if item and item not in available_items
            )
            if invalid_items:
                messagebox.showerror(
                    "Invalid Player Inventory",
                    "Choose items from the available object list.",
                )
                return False
            player["starting_inventory"] = inventory
        player["stats"] = stats
        if hasattr(self, "remember_editor_form"):
            self.remember_editor_form("player", [*getattr(self, "player_stat_vars", {}).values(),
                                                 *getattr(self, "player_inventory_vars", [])])
        return True

    def set_player_start(self, x, y):
        if (not self.current_area_file or
                not self._is_project_area(self.current_area_file)):
            messagebox.showwarning(
                "Player Start",
                "Save this area in the project's areas folder before setting it as the start area.",
            )
            return False
        if not (0 <= x < self.current_area.width and 0 <= y < self.current_area.height):
            messagebox.showwarning(
                "Player Start", "Choose a tile inside the area for the player start."
            )
            return False

        area_filename = os.path.basename(self.current_area_file)
        if area_filename not in self.current_game.areas:
            self.current_game.areas.append(area_filename)

        properties = self.current_game.properties
        properties["start_area"] = area_filename
        properties["start_x"] = x
        properties["start_y"] = y
        player = self.get_player_settings()
        player["sprite"] = self.selected_tile
        self.refresh_game_areas_list()
        self.refresh_player_setup()
        self.draw_area()
        self.update_properties_display()
        return True
    
    def on_key_press(self, event):
        key = event.keysym.lower()
        if getattr(self, "_trigger_position_picker", None) is not None:
            if key == "escape":
                self._trigger_position_picker = None
                self._restore_coordinate_picker_area()
            return "break"
        if self.root.focus_get() == self.canvas:
            if self.selected_mode in ("messages", "editor_help"):
                return "break"
            if key in ['up', 'down', 'left', 'right']:
                self.move_cursor(key)
                return "break"
            elif key == 'space':
                self.place_tile()
                return "break"
            elif key == 'delete' or key == 'backspace':
                self.delete_location()
                return "break"
            elif key in ['1', '2', '3', '4', '5', '6', '7', '8', '9', '0']:
                self.select_trigger(10 if key == "0" else int(key))
                return "break"
            elif key == 'return':  # Enter key
                self.edit_selected_trigger()
                return "break"
    
    def select_trigger(self, trigger_number):
        """Select a specific trigger at the current location"""
        triggers_here = [trig for trig in self.current_area.triggers 
                        if trig.x == self.cursor_x and trig.y == self.cursor_y]
        if triggers_here and 1 <= trigger_number <= len(triggers_here):
            self.select_trigger_index(trigger_number - 1)

    def select_trigger_index(self, index):
        triggers_here = self._triggers_at_cursor()
        if not triggers_here or not 0 <= index < len(triggers_here):
            return False
        if index == self.selected_trigger_index:
            return True
        if not self.save_selected_trigger(show_error=True, refresh=False):
            return False
        self.selected_trigger_index = index
        self.refresh_trigger_editor()
        self.update_properties_display()
        self.draw_area()
        return True

    def edit_selected_trigger(self):
        """Focus the selected trigger editor in the properties panel."""
        self.refresh_trigger_editor()
    
    def get_next_trigger_name(self):
        """Generate the next available trigger name (trigger_1, trigger_2, etc.)"""
        existing_names = [trig.name for trig in self.current_area.triggers]
        counter = 1
        while f"trigger_{counter}" in existing_names:
            counter += 1
        return f"trigger_{counter}"
    
    def place_tile(self):
        if self.selected_mode == "player":
            self.set_player_start(self.cursor_x, self.cursor_y)
        elif self.selected_mode == "enemy":
            self.place_selected_enemy()
        elif self.selected_mode == "tile":
            current_tile = self.current_area.tiles[self.cursor_y][self.cursor_x]
            if current_tile.type == self.selected_tile:
                from data_classes import Tile
                self.current_area.tiles[self.cursor_y][self.cursor_x] = Tile(type="empty")
            else:
                from data_classes import Tile
                self.current_area.tiles[self.cursor_y][self.cursor_x] = Tile(type=self.selected_tile)
        
        elif self.selected_mode == "object":
            existing = [obj for obj in self.current_area.objects 
                       if obj.x == self.cursor_x and obj.y == self.cursor_y]
            if existing and existing[0].type == self.selected_tile:
                self.current_area.objects = [obj for obj in self.current_area.objects 
                                           if not (obj.x == self.cursor_x and obj.y == self.cursor_y)]
            else:
                self.current_area.objects = [obj for obj in self.current_area.objects 
                                           if not (obj.x == self.cursor_x and obj.y == self.cursor_y)]
                from data_classes import GameObject
                self.current_area.objects.append(GameObject(
                    type=self.selected_tile, x=self.cursor_x, y=self.cursor_y))
        
        elif self.selected_mode == "npc":
            npc_types = set(self.tile_manager.get_npc_names()) or {"guard", "merchant", "villager"}
            existing = [obj for obj in self.current_area.objects 
                       if obj.x == self.cursor_x and obj.y == self.cursor_y and obj.type in npc_types]
            if existing and existing[0].type == self.selected_tile:
                self.current_area.objects = [obj for obj in self.current_area.objects 
                                           if not (obj.x == self.cursor_x and obj.y == self.cursor_y and 
                                                  obj.type in npc_types)]
            else:
                self.current_area.objects = [obj for obj in self.current_area.objects 
                                           if not (obj.x == self.cursor_x and obj.y == self.cursor_y and 
                                                  obj.type in npc_types)]
                from data_classes import GameObject
                self.current_area.objects.append(GameObject(
                    type=self.selected_tile, x=self.cursor_x, y=self.cursor_y))
        
        elif self.selected_mode == "trigger":
            if self.selected_tile == "named_trigger":
                self.place_reusable_trigger()
                return
            triggers_here = [trig for trig in self.current_area.triggers 
                           if trig.x == self.cursor_x and trig.y == self.cursor_y]
            if self.selected_mode == "trigger" and not self.save_selected_trigger(
                show_error=True, refresh=False
            ):
                return
            from data_classes import Trigger
            new_trigger = Trigger(
                x=self.cursor_x, 
                y=self.cursor_y,
                trigger_type=self.selected_tile,  # selected_tile now holds trigger type
                name=self.get_next_trigger_name()
            )
            self.current_area.triggers.append(new_trigger)
            self.selected_trigger_index = len(triggers_here)  # Select the new trigger
            self.refresh_trigger_editor()
        self.draw_area()
        self.update_properties_display()

    def fill_tiles(self):
        """Fill matching four-connected tiles with horizontal spans from the cursor."""
        if self.selected_mode != "tile":
            messagebox.showwarning("Fill", "Select Tiles mode before filling the area.")
            return 0

        from data_classes import Tile
        area = self.current_area
        x, y = self.cursor_x, self.cursor_y
        if not (0 <= x < area.width and 0 <= y < area.height):
            return 0
        replacement = self.selected_tile
        seeds = [(x, y)]
        if area.tiles[y][x].type == replacement:
            # Snapshot all neighboring source types before any region is changed.
            seeds = [(x + dx, y + dy) for dx, dy in ((1, 0), (0, 1), (-1, 0), (0, -1))
                     if 0 <= x + dx < area.width and 0 <= y + dy < area.height]
        pending = [(sx, sy, area.tiles[sy][sx].type) for sx, sy in seeds
                   if area.tiles[sy][sx].type != replacement]
        filled_count = 0
        while pending:
            sx, sy, source = pending.pop()
            if area.tiles[sy][sx].type != source:
                continue
            left = right = sx
            while left > 0 and area.tiles[sy][left - 1].type == source:
                left -= 1
            while right + 1 < area.width and area.tiles[sy][right + 1].type == source:
                right += 1
            for column in range(left, right + 1):
                area.tiles[sy][column] = Tile(type=replacement)
                filled_count += 1
            # Only edge-sharing spans connect: never cross diagonal border contacts.
            for row in (sy - 1, sy + 1):
                if not 0 <= row < area.height:
                    continue
                in_span = False
                for column in range(left, right + 1):
                    matches = area.tiles[row][column].type == source
                    if matches and not in_span:
                        pending.append((column, row, source))
                    in_span = matches
        if filled_count:
            self.draw_area()
            self.update_properties_display()
        return filled_count

    def fill_empty_tiles(self):
        """Compatibility entry point for existing editor automation."""
        return self.fill_tiles()

    def remove_tile(self):
        if self.selected_mode == "tile":
            from data_classes import Tile
            self.current_area.tiles[self.cursor_y][self.cursor_x] = Tile(type="empty")
        elif self.selected_mode == "object":
            npc_types = set(self.tile_manager.get_npc_names()) or {"guard", "merchant", "villager"}
            self.current_area.objects = [obj for obj in self.current_area.objects 
                                       if not (obj.x == self.cursor_x and obj.y == self.cursor_y and 
                                              obj.type not in npc_types)]
        elif self.selected_mode == "enemy":
            self.remove_enemies_at_cursor()
        elif self.selected_mode == "npc":
            npc_types = set(self.tile_manager.get_npc_names()) or {"guard", "merchant", "villager"}
            self.current_area.objects = [obj for obj in self.current_area.objects 
                                       if not (obj.x == self.cursor_x and obj.y == self.cursor_y and 
                                              obj.type in npc_types)]
        elif self.selected_mode == "trigger":
            self.delete_selected_trigger(confirm=False)
        
        self.draw_area()
        self.update_properties_display()
    
    def move_cursor(self, direction):
        if self.selected_mode == "trigger" and not self.save_selected_trigger(
            show_error=True, refresh=False
        ):
            return
        if direction == 'up' and self.cursor_y > 0:
            self.cursor_y -= 1
        elif direction == 'down' and self.cursor_y < self.current_area.height - 1:
            self.cursor_y += 1
        elif direction == 'left' and self.cursor_x > 0:
            self.cursor_x -= 1
        elif direction == 'right' and self.cursor_x < self.current_area.width - 1:
            self.cursor_x += 1
        
        # Reset trigger selection when moving to new location
        self.selected_trigger_index = 0
        self.update_cursor_display()
        self.refresh_trigger_editor()
        self.update_properties_display()
    
    def on_canvas_click(self, event):
        position_picker = getattr(self, "_trigger_position_picker", None)
        if position_picker is not None:
            canvas_x = self.canvas.canvasx(event.x)
            canvas_y = self.canvas.canvasy(event.y)
            grid_x = int(canvas_x // self.tile_size)
            grid_y = int(canvas_y // self.tile_size)
            if (0 <= grid_x < self.current_area.width and
                    0 <= grid_y < self.current_area.height):
                position_picker["x_var"].set(str(grid_x))
                position_picker["y_var"].set(str(grid_y))
                self._trigger_position_picker = None
                self._restore_coordinate_picker_area()
            self.canvas.focus_set()
            return "break"

        if self.selected_mode in ("messages", "editor_help"):
            return

        canvas_x = self.canvas.canvasx(event.x)
        canvas_y = self.canvas.canvasy(event.y)
        grid_x = int(canvas_x // self.tile_size)
        grid_y = int(canvas_y // self.tile_size)

        trigger_variables = getattr(self, "_trigger_editor_vars", {})
        if (
            self.selected_mode == "trigger"
            and getattr(self, "_trigger_editor_trigger", None) is not None
            and getattr(self, "_trigger_editor_draft_type", None) == "tile_update"
            and "x" in trigger_variables
            and "y" in trigger_variables
        ):
            area_variable = trigger_variables.get("area")
            selected_area = area_variable.get() if area_variable is not None else ""
            current_file = getattr(self, "current_area_file", None) if selected_area not in ("", "Current area") else None
            current_name = os.path.splitext(os.path.basename(current_file))[0] if current_file else ""
            if selected_area not in ("", "Current area", current_name):
                self.canvas.focus_set()
                return "break"
            if (
                0 <= grid_x < self.current_area.width
                and 0 <= grid_y < self.current_area.height
            ):
                trigger_variables["x"].set(str(grid_x))
                trigger_variables["y"].set(str(grid_y))
                self.mouse_position_label.config(
                    text=f"Mouse: ({grid_x}, {grid_y})"
                )
            else:
                self.mouse_position_label.config(text="Mouse: --")
            self.canvas.focus_set()
            return "break"

        if self.selected_mode == "trigger" and not self.save_selected_trigger(
            show_error=True, refresh=False
        ):
            return "break"
        self.canvas.focus_set()
        
        if (0 <= grid_x < self.current_area.width and 0 <= grid_y < self.current_area.height):
            if self.selected_mode == "player":
                self.cursor_x = grid_x
                self.cursor_y = grid_y
                self.update_cursor_display()
                self.set_player_start(grid_x, grid_y)
                return "break"
            self.cursor_x = grid_x
            self.cursor_y = grid_y
            self.selected_trigger_index = 0  # Reset trigger selection
            self.update_cursor_display()
            self.refresh_trigger_editor()
            self.update_properties_display()

    def _begin_trigger_position_pick(
            self, x_var, y_var, destination_area_name=None
    ):
            area = self.current_area
            area_file = self.current_area_file
            if destination_area_name:
                destination_filename = next(
                    (
                        filename for filename in self.current_game.areas
                        if os.path.splitext(os.path.basename(filename))[0]
                        == destination_area_name
                    ),
                    None,
                )
                if destination_filename is None:
                    messagebox.showerror(
                        "Pick Coordinates",
                        "Choose a destination area that belongs to this game.",
                    )
                    return False

                destination_path = self._project_path(
                    "areas", destination_filename
                )
                if (
                    area_file
                    and os.path.realpath(area_file) == os.path.realpath(destination_path)
                ):
                    destination_area = area
                else:
                    try:
                        destination_area = self._read_area_file(destination_path)
                    except FileNotFoundError:
                        messagebox.showerror(
                            "Save Destination Area First",
                            "Save the destination area first, then choose its coordinates.",
                        )
                        return False
                    except (OSError, ValueError, TypeError, KeyError) as error:
                        messagebox.showerror(
                            "Pick Coordinates",
                            f"Could not load destination area "
                            f"{destination_filename}: {error}",
                        )
                        return False
                area = destination_area
                area_file = destination_path

            self._coordinate_picker_source = (
                self.current_area,
                self.current_area_file,
                self.cursor_x,
                self.cursor_y,
                self.selected_trigger_index,
            )
            self.current_area = area
            self.current_area_file = area_file
            self._trigger_position_picker = {"x_var": x_var, "y_var": y_var}
            try:
                target_x = int(x_var.get())
                target_y = int(y_var.get())
            except (ValueError, TypeError):
                target_x = target_y = 0
            if not (
                0 <= target_x < area.width and 0 <= target_y < area.height
            ):
                target_x = target_y = 0
            self.cursor_x, self.cursor_y = target_x, target_y
            self.draw_area()
            self.cursor_label.config(
                text=f"Click target cell in {area.name} (Esc to cancel)"
            )
            self.canvas.focus_set()
            return True

    def _restore_coordinate_picker_area(self):
            source = getattr(self, "_coordinate_picker_source", None)
            if source is None:
                self.update_cursor_display()
                return
            (
                self.current_area,
                self.current_area_file,
                self.cursor_x,
                self.cursor_y,
                self.selected_trigger_index,
            ) = source
            self._coordinate_picker_source = None
            self.draw_area()

    def _location_edit_allowed(self):
        return (getattr(self, "_trigger_position_picker", None) is None
                and self.selected_mode not in ("messages", "editor_help")
                and 0 <= self.cursor_x < self.current_area.width
                and 0 <= self.cursor_y < self.current_area.height)

    def _commit_location_form(self):
        return self.save_selected_trigger(show_error=True, refresh=False)

    def _refresh_location_edit(self):
        self._trigger_editor_trigger = None
        self._trigger_editor_vars = {}
        self.selected_trigger_index = 0
        self.refresh_trigger_editor()
        self.draw_area()
        self.update_properties_display()

    def copy_location(self):
        if not self._location_edit_allowed() or not self._commit_location_form():
            return False
        x, y = self.cursor_x, self.cursor_y
        self._location_clipboard = {
            "tile": deepcopy(self.current_area.tiles[y][x]),
            "objects": deepcopy([obj for obj in self.current_area.objects if (obj.x, obj.y) == (x, y)]),
            "triggers": deepcopy([trig for trig in self.current_area.triggers if (trig.x, trig.y) == (x, y)]),
            "definitions": deepcopy(getattr(getattr(self, "current_game", None), "properties", {}).get("trigger_definitions", {})),
            "position": (x, y), "area": self.current_area,
            "area_file": getattr(self, "current_area_file", None), "move": False,
        }
        return True

    def _clear_location(self):
        from data_classes import Tile
        x, y = self.cursor_x, self.cursor_y
        self.current_area.tiles[y][x] = Tile(type="empty")
        self.current_area.objects = [obj for obj in self.current_area.objects if (obj.x, obj.y) != (x, y)]
        self.current_area.triggers = [trig for trig in self.current_area.triggers if (trig.x, trig.y) != (x, y)]

    def cut_location(self):
        if not self.copy_location():
            return False
        self._location_clipboard["move"] = True
        self._clear_location()
        self._refresh_location_edit()
        return True

    def delete_location(self):
        if not self._location_edit_allowed() or not self._commit_location_form():
            return False
        self._clear_location()
        self._refresh_location_edit()
        return True

    def paste_location(self):
        clipboard = getattr(self, "_location_clipboard", None)
        if not clipboard or not self._location_edit_allowed() or not self._commit_location_form():
            return False
        x, y = self.cursor_x, self.cursor_y
        objects = deepcopy(clipboard["objects"])
        triggers = deepcopy(clipboard["triggers"])
        if hasattr(self, "import_clipboard_triggers"):
            try:
                self.import_clipboard_triggers(clipboard, triggers)
            except ValueError as error:
                messagebox.showerror("Paste", str(error))
                return False
        same_area = clipboard["area"] is self.current_area
        move = clipboard["move"] and same_area
        for obj in objects:
            obj.x, obj.y = x, y
            if "enemy_id" in obj.properties or "enemy_data" in obj.properties:
                original = obj.properties.get("enemy_instance_id")
                identity = original if move and original else f"enemy_instance_{uuid4().hex}"
                obj.properties["enemy_instance_id"] = identity
        source_file = clipboard["area_file"]
        source_stem = os.path.splitext(os.path.basename(source_file))[0] if source_file else None
        for trigger in triggers:
            trigger.x, trigger.y = x, y
            if trigger.definition_id:
                trigger.remaining_charges = None
                continue
            params = trigger.parameters
            target_area = params.get("area", "")
            local = not target_area or (source_stem is not None and os.path.splitext(os.path.basename(target_area))[0] == source_stem)
            # Retarget actions on the copied stack, preserving unrelated destinations.
            if (trigger.trigger_type in ("area_object", "tile_update", "enemy_placement") and local
                    and (params.get("x"), params.get("y")) == clipboard["position"]):
                params["x"], params["y"] = x, y
                if trigger.trigger_type in ("area_object", "tile_update", "enemy_placement"):
                    params["area"] = ""
        self._clear_location()
        self.current_area.tiles[y][x] = deepcopy(clipboard["tile"])
        self.current_area.objects.extend(objects)
        self.current_area.triggers.extend(triggers)
        clipboard["move"] = False
        self._refresh_location_edit()
        return True

    def populate_location_menu(self, menu):
        enabled = self._location_edit_allowed()
        for label, command in (("Cut", self.cut_location), ("Copy", self.copy_location),
                               ("Paste", self.paste_location), ("Delete", self.delete_location)):
            state = tk.NORMAL if enabled and (label != "Paste" or getattr(self, "_location_clipboard", None)) else tk.DISABLED
            menu.add_command(label=label, command=command, state=state)

    def refresh_edit_menu(self):
        self.edit_menu.delete(0, tk.END)
        self.populate_location_menu(self.edit_menu)

    def on_canvas_right_click(self, event):
        if (getattr(self, "_trigger_position_picker", None) is not None or
                self.selected_mode in ("messages", "editor_help")):
            return "break"
        grid_x = int(self.canvas.canvasx(event.x) // self.tile_size)
        grid_y = int(self.canvas.canvasy(event.y) // self.tile_size)
        if not (0 <= grid_x < self.current_area.width and 0 <= grid_y < self.current_area.height):
            return "break"
        if not self._commit_location_form():
            return "break"
        self.canvas.focus_set()
        self.cursor_x, self.cursor_y = grid_x, grid_y
        self.selected_trigger_index = 0
        self.update_cursor_display()
        self.refresh_trigger_editor()
        self.update_properties_display()
        previous = getattr(self, "_location_context_menu", None)
        if previous is not None:
            previous.destroy()
        menu = self._location_context_menu = tk.Menu(self.canvas, tearoff=0)
        self.populate_location_menu(menu)
        try:
            menu.tk_popup(event.x_root, event.y_root)
        finally:
            menu.grab_release()
        return "break"

    def on_canvas_motion(self, event):
        canvas_x = self.canvas.canvasx(event.x)
        canvas_y = self.canvas.canvasy(event.y)
        grid_x = int(canvas_x // self.tile_size)
        grid_y = int(canvas_y // self.tile_size)
        if (0 <= grid_x < self.current_area.width and
                0 <= grid_y < self.current_area.height):
            self.mouse_position_label.config(text=f"Mouse: ({grid_x}, {grid_y})")
        else:
            self.mouse_position_label.config(text="Mouse: --")

    def on_canvas_leave(self, _event=None):
        self.mouse_position_label.config(text="Mouse: --")

    def on_tile_canvas_click(self, event):
        if self.selected_mode == "enemy":
            canvas_y = self.tile_canvas.canvasy(event.y)
            row_index = int((canvas_y - 10) // 40)
            enemy_ids = list(self.get_enemy_definitions())
            if (
                0 <= row_index < len(enemy_ids)
                and 10 + row_index * 40 <= canvas_y < 42 + row_index * 40
            ):
                self.select_enemy_definition(row_index)
            return

        if self.selected_mode in ("npc", "player"):
            npc_names = self.tile_manager.get_npc_names()
            canvas_y = self.tile_canvas.canvasy(event.y)
            row_index = int((canvas_y - 10) // 40)
            if (
                0 <= row_index < len(npc_names)
                and 10 + row_index * 40 <= canvas_y < 40 + row_index * 40
            ):
                self.selected_tile = npc_names[row_index]
                self.update_tile_display()
                if self.selected_mode == "player":
                    self.get_player_settings()["sprite"] = self.selected_tile
                    self.draw_area()
            return

        if self.selected_mode in ("tile", "object", "trigger", "messages"):
            # Canvas item IDs and selection outlines are not hit targets. Use the
            # scrolled content coordinates to select the displayed grid cell/row.
            x = self.tile_canvas.canvasx(event.x)
            y = self.tile_canvas.canvasy(event.y)
            if self.selected_mode == "tile":
                column, row = int((x - 10) // 40), int((y - 10) // 40)
                names = self.tile_manager.get_tile_names()
                index = row * 5 + column
                if not (0 <= column < 5 and row >= 0 and 0 <= index < len(names)
                        and 10 + column * 40 <= x < 42 + column * 40
                        and 10 + row * 40 <= y < 42 + row * 40):
                    return
                self.selected_tile = names[index]
                self.update_tile_display()
            elif self.selected_mode == "messages":
                index = int((y - 15) // 55)
                if 0 <= index < 3 and 15 + index * 55 <= y < 55 + index * 55:
                    self.edit_game_message(("intro", "instructions", "game_end")[index])
            else:
                index = int((y - 10) // 40)
                names = (self.tile_manager.get_object_names() or ["item", "lever", "fountain", "chest", "barrel"]
                         if self.selected_mode == "object" else
                         ["teleport", "inventory", "player_stats", "funds", "tile_update", "area_object", "game_end", "show_message", "play_sound", "trigger_control", "enemy_placement", "named_trigger"])
                if not (0 <= index < len(names) and 8 <= x < 220
                        and 10 + index * 40 <= y < 46 + index * 40):
                    return
                self.selected_tile = names[index]
                self.update_tile_display()
                if self.selected_mode == "object":
                    self.load_object_definition_editor()
                self.update_properties_display()
            return

        clicked = self.tile_canvas.find_closest(event.x, event.y)[0]
        tags = self.tile_canvas.gettags(clicked)
        for tag in tags:
            if tag.startswith("message_"):
                self.edit_game_message(tag[8:])
                break
            if tag.startswith("tile_"):
                self.selected_tile = tag[5:]
                self.update_tile_display()
                break
            elif tag.startswith("obj_"):
                self.selected_tile = tag[4:]
                self.update_tile_display()
                self.load_object_definition_editor()
                self.update_properties_display()
                break
            elif tag.startswith("npc_"):
                self.selected_tile = tag[4:]
                self.update_tile_display()
                if self.selected_mode == "player":
                    self.get_player_settings()["sprite"] = self.selected_tile
                    self.draw_area()
                break
            elif tag.startswith("trigger_"):
                self.selected_tile = tag[8:]  # trigger type (e.g., "teleport")
                self.update_tile_display()
                self.update_properties_display()
                break
    
    def on_mode_change(self):
        previous_mode = getattr(self, "selected_mode", None)
        if previous_mode == "enemy" and not self.save_enemy_definition():
            self.mode_var.set(previous_mode)
            return
        if previous_mode == "trigger" and not self.save_selected_trigger(
            show_error=True, refresh=False
        ):
            self.mode_var.set(previous_mode)
            return

        self.selected_mode = self.mode_var.get()
        if self.selected_mode == "enemy":
            self.refresh_enemy_editor()
        elif self.selected_mode == "trigger":
            self.selected_tile = "teleport"
        elif self.selected_mode == "player":
            player = self.get_player_settings()
            npc_names = self.tile_manager.get_npc_names()
            self.selected_tile = (
                player["sprite"] if player["sprite"] in npc_names
                else (npc_names[0] if npc_names else "fighter_npc")
            )
            player["sprite"] = self.selected_tile
        elif self.selected_mode == "tile" and self.tile_manager.get_tile_names():
            self.selected_tile = list(self.tile_manager.get_tile_names())[0]
        elif self.selected_mode == "object":
            self.selected_tile = (self.tile_manager.get_object_names() or
                                  ["item", "lever", "fountain", "chest", "barrel"])[0]
        elif self.selected_mode == "npc":
            self.selected_tile = (self.tile_manager.get_npc_names() or
                                  ["guard", "merchant", "villager", "wizard", "knight"])[0]
        if hasattr(self, "trigger_editor_frame"):
            if self.selected_mode == "trigger":
                self.tile_walkable_frame.pack_forget()
                self.object_definition_frame.pack_forget()
                self.details_label.pack_forget()
                self.properties_text.pack_forget()
                self.trigger_editor_frame.pack(
                    fill=tk.BOTH, expand=True, padx=5, pady=5
                )
            else:
                self.trigger_editor_frame.pack_forget()
                self.details_label.pack(padx=5, pady=(10, 0))
                self.properties_text.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        if hasattr(self, "player_setup_frame"):
            if self.selected_mode == "player":
                self.tile_walkable_frame.pack_forget()
                self.object_definition_frame.pack_forget()
                if hasattr(self, "player_inventory_frame"):
                    self.player_inventory_frame.pack(
                        before=self.tile_canvas_frame,
                        fill=tk.X,
                        padx=5,
                        pady=(0, 4),
                    )
                self.details_label.pack(padx=5, pady=(10, 0))
                self.properties_text.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
                self.player_setup_frame.pack(
                    before=self.details_label, fill=tk.X, padx=5, pady=5
                )
                self.details_label.pack_forget()
                self.properties_text.pack_forget()
                self.refresh_player_setup()
            else:
                self.player_setup_frame.pack_forget()
                if hasattr(self, "player_inventory_frame"):
                    self.player_inventory_frame.pack_forget()
        if hasattr(self, "enemy_properties_frame"):
            if self.selected_mode == "enemy":
                self.tile_walkable_frame.pack_forget()
                self.object_definition_frame.pack_forget()
                self.trigger_editor_frame.pack_forget()
                self.details_label.pack_forget()
                self.properties_text.pack_forget()
                self.player_setup_frame.pack_forget()
                self.enemy_properties_frame.pack(fill=tk.X, padx=5, pady=5)
                self.enemy_controls_frame.pack(fill=tk.X, padx=5, pady=5)
                self.select_enemy_at_cursor()
                self.refresh_enemy_editor()
            else:
                self.enemy_properties_frame.pack_forget()
                self.enemy_controls_frame.pack_forget()
        if hasattr(self, "object_definition_frame"):
            if self.selected_mode == "object":
                self.tile_walkable_frame.pack_forget()
                self.object_definition_frame.pack(
                    before=self.details_label, fill=tk.X, padx=5, pady=5
                )
                self.load_object_definition_editor()
            elif self.selected_mode in ("player", "enemy"):
                self.object_definition_frame.pack_forget()
                self.tile_walkable_frame.pack_forget()
            elif self.selected_mode == "trigger" and not hasattr(
                self, "trigger_editor_frame"
            ):
                self.object_definition_frame.pack_forget()
                self.tile_walkable_frame.pack_forget()
            elif self.selected_mode != "trigger":
                self.object_definition_frame.pack_forget()
                self.tile_walkable_frame.pack(
                    before=self.details_label, fill=tk.X, padx=5, pady=5
                )
        self.update_tile_display()
        if hasattr(self, "trigger_listbox"):
            self.refresh_trigger_editor()
        self.update_properties_display()

    def load_object_definition_editor(self):
        if self.selected_mode != "object":
            return
        definition = self.current_game.get_object_definition(self.selected_tile)
        if hasattr(self, "object_item_type_var"):
            self.object_item_type_var.set(definition["item_type"])
            self.object_weapon_damage_var.set(str(definition["weapon_damage"]))
            if hasattr(self, "item_detail_vars"):
                for key, variable in self.item_detail_vars.items():
                    value = definition[key]
                    variable.set(("yes" if value else "no") if key == "ranged" else str(value))
            self.on_object_item_type_change()
        self.object_gettable_var.set(definition["gettable"])
        self.object_walkable_var.set(definition["walkable"])
        self.object_effect_mode_var.set(definition["effect_mode"])
        for stat, value_var in self.object_effect_vars.items():
            value_var.set(str(definition["effects"].get(stat, 0)))
        self.on_object_gettable_change()
        self._remember_object_form()

    def _remember_object_form(self):
        if hasattr(self, "remember_editor_form"):
            variables = [self.object_gettable_var, self.object_walkable_var, self.object_effect_mode_var,
                         *self.object_effect_vars.values()]
            if hasattr(self, "object_item_type_var"):
                variables += [self.object_item_type_var, self.object_weapon_damage_var]
            variables += list(getattr(self, "item_detail_vars", {}).values())
            self.remember_editor_form("object", variables)

    def on_object_item_type_change(self, _event=None):
        kind = self.object_item_type_var.get()
        if kind not in ("object", "openable"):
            self.object_gettable_var.set(True)
        self.on_object_gettable_change()
        if kind == "weapon":
            self.object_weapon_frame.pack(fill=tk.X, padx=5, pady=3, before=self.object_save_button)
        else:
            self.object_weapon_frame.pack_forget()
        for group, frame in getattr(self, "item_detail_frames", {}).items():
            if group == kind:
                frame.pack(fill=tk.X, padx=5, pady=3, before=self.object_save_button)
            else:
                frame.pack_forget()
        if kind == "consumable":
            self.object_effect_mode_var.set("consumable")
        if kind == "armor" and hasattr(self, "item_detail_vars"):
            variable = self.item_detail_vars["equipment_slot"]
            if variable.get() not in ("head", "offhand"):
                variable.set("head")

    def on_object_gettable_change(self):
        kind = self.object_item_type_var.get() if hasattr(self, "object_item_type_var") else "object"
        if self.object_gettable_var.get() and kind in ("object", "consumable"):
            self.object_effects_frame.pack(fill=tk.X, padx=5, pady=3)
        else:
            self.object_effects_frame.pack_forget()

    def save_object_definition_changes(self):
        object_type = self.selected_tile
        if self.selected_mode != "object":
            return False

        weapon_settings = {}
        if hasattr(self, "object_item_type_var"):
            item_type = self.object_item_type_var.get()
            try:
                weapon_damage = int(self.object_weapon_damage_var.get()) if item_type == "weapon" else 0
            except ValueError:
                messagebox.showerror("Invalid Weapon", "Weapon damage bonus must be a whole number.")
                return False
            if item_type not in ITEM_TYPES or weapon_damage < 0:
                messagebox.showerror("Invalid Weapon", "Choose an item type and a non-negative damage bonus.")
                return False
            weapon_settings = {"item_type": item_type, "weapon_damage": weapon_damage}
            if item_type not in ("object", "openable"):
                self.object_gettable_var.set(True)
            if hasattr(self, "item_detail_vars"):
                try:
                    for key, variable in self.item_detail_vars.items():
                        value = variable.get()
                        weapon_settings[key] = (value == "yes") if key == "ranged" else (
                            int(value) if key in ("armor_bonus", "attack_range", "energy_cost") else value
                        )
                    if item_type == "armor" and not weapon_settings.get("equipment_slot"):
                        weapon_settings["equipment_slot"] = "head"
                    validate_item(weapon_settings)
                except (ValueError, TypeError) as error:
                    messagebox.showerror("Invalid Item", str(error))
                    return False

        if self.object_gettable_var.get():
            try:
                effects = {
                    stat: int(value_var.get())
                    for stat, value_var in self.object_effect_vars.items()
                }
            except ValueError:
                messagebox.showerror("Invalid Effect", "Stat effects must be whole numbers.")
                return False
        else:
            effects = {stat: 0 for stat in self.object_effect_vars}

        self.current_game.object_definitions[object_type] = {
            **self.current_game.object_definitions.get(object_type, {}),
            **weapon_settings,
            "gettable": self.object_gettable_var.get(),
            "walkable": self.object_walkable_var.get(),
            "effect_mode": "consumable" if weapon_settings.get("item_type") == "consumable" else self.object_effect_mode_var.get(),
            "effects": effects,
        }
        self.draw_area()
        self.update_properties_display()
        self._remember_object_form()
        return True

    def get_trigger_type_description(self, trigger_type):
        descriptions = {
            "teleport": "Moves the player to another area.",
            "inventory": "Adds or removes an item from the player's inventory.",
            "player_stats": "Changes a player stat by a signed amount.",
            "funds": "Adds or removes funds. Removal requires sufficient funds.",
            "trigger_control": "Enables or disables all placements of a named trigger.",
            "enemy_placement": "Places or removes enemies of a chosen type, including all instances.",
            "named_trigger": "Places an existing named trigger from this game.",
            "tile_update": "Changes a tile in a selected area.",
            "area_object": "Adds or removes an object on an area map.",
            "game_end": "Ends the game with a win or loss.",
            "show_message": "Displays a message to the player.",
            "play_sound": "Plays a WAV file once or loops it.",
            "custom": "Legacy custom scripts are not supported by the runner.",
        }
        return descriptions.get(trigger_type, "Unknown trigger type.")

    def edit_game_message(self, message_type):
        message_fields = {
            "intro": ("Intro Message", "intro_message"),
            "instructions": ("Help / Instructions Message", "instructions_message"),
            "game_end": ("Game End Message", "game_end_message"),
        }
        if message_type not in message_fields:
            return

        title, field_name = message_fields[message_type]
        dialog = tk.Toplevel(self.root)
        dialog.title(title)
        dialog.geometry("500x350")
        dialog.transient(self.root)

        button_frame = ttk.Frame(dialog)
        button_frame.pack(side=tk.BOTTOM, fill=tk.X, padx=10, pady=(0, 10))
        ttk.Button(button_frame, text="Cancel", command=dialog.destroy).pack(side=tk.RIGHT)

        message_text = tk.Text(dialog, wrap=tk.WORD)
        message_text.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        message_text.insert("1.0", getattr(self.current_game, field_name))

        def save_message():
            setattr(self.current_game, field_name, message_text.get("1.0", tk.END).rstrip("\n"))
            dialog.destroy()

        ttk.Button(button_frame, text="Save", command=save_message).pack(side=tk.RIGHT, padx=(5, 0))
    
    def show_area_music(self):
        from pathlib import Path
        import wave
        from project_paths import asset_root

        area = self.current_area
        dialog = tk.Toplevel(self.root)
        dialog.title("Area Ambient Music")
        dialog.transient(self.root)
        dialog.grab_set()
        frame = ttk.Frame(dialog, padding=12)
        frame.pack(fill=tk.BOTH, expand=True)
        ttk.Label(frame, text=f"Music for {area.name}").pack(anchor=tk.W)
        library = Path(project_root()) / "music"
        tracks = sorted({path.name for directory in (library, asset_root() / "music")
                         for path in directory.glob("*")
                         if path.is_file() and path.suffix.lower() == ".wav"}
                        | ({area.ambient_music} if area.ambient_music else set()))
        selected = tk.StringVar(value=area.ambient_music or "None")
        selector = ttk.Combobox(frame, textvariable=selected,
                                values=["None", *tracks], state="readonly", width=45)
        selector.pack(fill=tk.X, pady=8)

        def import_track():
            filename = filedialog.askopenfilename(
                parent=dialog, title="Import Ambient Music",
                filetypes=[("WAV audio", "*.wav")],
            )
            if not filename:
                return
            try:
                from wav_assets import import_wav
                name = import_wav(filename, library)
                if name not in tracks:
                    tracks.append(name)
                selector.configure(values=["None", *sorted(tracks)])
                selected.set(name)
            except (OSError, ValueError, wave.Error, EOFError) as error:
                messagebox.showerror("Import Music", str(error), parent=dialog)

        def save():
            area.ambient_music = "" if selected.get() == "None" else selected.get()
            dialog.destroy()

        ttk.Button(frame, text="Import WAV", command=import_track).pack(side=tk.LEFT)
        ttk.Button(frame, text="Save", command=save).pack(side=tk.RIGHT)
        ttk.Button(frame, text="Cancel", command=dialog.destroy).pack(side=tk.RIGHT, padx=6)

    def on_area_name_change(self, *_args):
        self.current_area.name = self.area_name_var.get()

    def on_game_name_change(self, *_args):
        self.current_game.name = self.game_name_var.get()
    
    def on_walkable_change(self):
        if self.selected_mode in ("messages", "editor_help"):
            return

        tile = self.current_area.tiles[self.cursor_y][self.cursor_x]
        value = self.walkable_override_var.get()
        if value == "default":
            tile.walkable_override = None
        elif value == "walkable":
            tile.walkable_override = True
        else:
            tile.walkable_override = False
        self.update_properties_display()
        self.draw_area()
    
    def is_tile_blocked(self, x, y):
        tile = self.current_area.tiles[y][x]
        if not tile.is_walkable(self.tile_manager):
            return True
        
        npc_names = set(self.tile_manager.get_npc_names())
        for obj in self.current_area.objects:
            if obj.x == x and obj.y == y:
                if obj.type in npc_names:
                    if obj.properties.get("walkable", False) is False:
                        return True
                else:
                    walkable = self.current_game.get_object_definition(obj.type)["walkable"]
                    if obj.properties.get("walkable", walkable) is False:
                        return True
        
        return False
    
    def draw_area(self):
        self.canvas.delete("all")
        
        for y in range(self.current_area.height):
            for x in range(self.current_area.width):
                x1, y1 = x * self.tile_size, y * self.tile_size
                tile = self.current_area.tiles[y][x]
                tile_info = self.tile_manager.get_tile_info(tile.type)
                
                if "image" in tile_info:
                    self.canvas.create_image(x1, y1, image=tile_info["image"], anchor=tk.NW)
                else:
                    self.canvas.create_rectangle(x1, y1, x1 + self.tile_size, y1 + self.tile_size, 
                                               fill="lightgray", outline="black")
                
                self.canvas.create_rectangle(x1, y1, x1 + self.tile_size, y1 + self.tile_size, 
                                           outline="gray", width=1)
                
                # Show non-walkable tiles
                if tile.type != "empty" and self.is_tile_blocked(x, y):
                    self.canvas.create_text(x1 + 16, y1 + 16, text="✗", fill="red", 
                                          font=("Arial", 12, "bold"))
        
        # Draw objects and NPCs
        for obj in self.current_area.objects:
            x1, y1 = obj.x * self.tile_size, obj.y * self.tile_size
            enemy_id = obj.properties.get("enemy_id")
            enemy_data = obj.properties.get("enemy_data")
            if enemy_id and hasattr(self, "get_enemy_definitions"):
                enemy_data = self.get_enemy_definitions().get(enemy_id, enemy_data)
            if enemy_data:
                sprite = enemy_data.get("sprite", obj.type)
                enemy_info = self.tile_manager.get_npc_info(sprite)
                if "image" in enemy_info:
                    self.canvas.create_image(
                        x1, y1, image=enemy_info["image"], anchor=tk.NW
                    )
                else:
                    self.canvas.create_rectangle(
                        x1 + 4, y1 + 4, x1 + 28, y1 + 28,
                        fill="#DC143C", outline="black", width=2,
                    )
                self.canvas.create_rectangle(
                    x1 + 1, y1 + 1, x1 + self.tile_size - 1,
                    y1 + self.tile_size - 1, outline="#DC143C", width=2,
                )
                continue
            npc_info = self.tile_manager.get_npc_info(obj.type)
            obj_info = self.tile_manager.get_object_info(obj.type)
            
            if "image" in npc_info:
                self.canvas.create_image(x1, y1, image=npc_info["image"], anchor=tk.NW)
            elif "image" in obj_info:
                self.canvas.create_image(x1, y1, image=obj_info["image"], anchor=tk.NW)
            else:
                x2, y2 = x1 + self.tile_size, y1 + self.tile_size
                if obj.type in ["guard", "merchant", "villager", "wizard", "knight", "enemy", "boss"]:
                    colors = {"guard": "#4169E1", "merchant": "#FFD700", "villager": "#90EE90",
                             "wizard": "#9370DB", "knight": "#C0C0C0", "enemy": "#DC143C", "boss": "#8B0000"}
                    color = colors.get(obj.type, "#FFD700")
                    self.canvas.create_oval(x1 + 4, y1 + 4, x2 - 4, y2 - 4, fill=color, outline="black", width=2)
                    self.canvas.create_text(x1 + 16, y1 + 16, text="N", fill="white", font=("Arial", 8, "bold"))
                else:
                    colors = {"item": "#32CD32", "lever": "#FF4500", "fountain": "#00CED1",
                             "chest": "#8B4513", "barrel": "#654321", "table": "#DEB887"}
                    color = colors.get(obj.type, "#32CD32")
                    self.canvas.create_rectangle(x1 + 4, y1 + 4, x2 - 4, y2 - 4, fill=color, outline="black", width=2)
        
        # Draw triggers with new color system
        trigger_locations = {}
        for trigger in self.current_area.triggers:
            key = (trigger.x, trigger.y)
            if key not in trigger_locations:
                trigger_locations[key] = []
            trigger_locations[key].append(trigger)
        
        for (x, y), triggers in trigger_locations.items():
            x1, y1 = x * self.tile_size, y * self.tile_size
            x2, y2 = x1 + self.tile_size, y1 + self.tile_size
            center_x, center_y = (x1 + x2) / 2, (y1 + y2) / 2
            
            top_trigger = triggers[0]
            if (x, y) == (self.cursor_x, self.cursor_y) and \
                    0 <= self.selected_trigger_index < len(triggers):
                top_trigger = triggers[self.selected_trigger_index]
            color = self.trigger_colors.get(top_trigger.trigger_type, "#CC0000")
            self.canvas.create_polygon(center_x, y1 + 4, x2 - 4, center_y, center_x, y2 - 4, x1 + 4, center_y,
                                     fill=color, outline="black", width=2)
            if len(triggers) > 1:
                marker_number = len(triggers)
                if (x, y) == (self.cursor_x, self.cursor_y):
                    marker_number = self.selected_trigger_index + 1
                number_color = (
                    "black"
                    if top_trigger.trigger_type in ("tile_update", "show_message")
                    else "white"
                )
                self.canvas.create_text(center_x, center_y, text=str(marker_number),
                                      fill=number_color, font=("Arial", 10, "bold"))

        properties = getattr(getattr(self, "current_game", None), "properties", {})
        start_area = properties.get("start_area")
        current_area_filename = (
            os.path.basename(self.current_area_file)
            if getattr(self, "current_area_file", None) else ""
        )
        start_x = properties.get("start_x")
        start_y = properties.get("start_y")
        if (start_area == current_area_filename and
                isinstance(start_x, int) and isinstance(start_y, int) and
                0 <= start_x < self.current_area.width and
                0 <= start_y < self.current_area.height):
            x1, y1 = start_x * self.tile_size, start_y * self.tile_size
            player = properties.get("player", {})
            sprite = player.get("sprite", "")
            player_info = self.tile_manager.get_npc_info(sprite)
            if "image" in player_info:
                self.canvas.create_image(
                    x1, y1, image=player_info["image"], anchor=tk.NW,
                    tags="player_start",
                )
            self.canvas.create_rectangle(
                x1 + 1, y1 + 1, x1 + self.tile_size - 1, y1 + self.tile_size - 1,
                outline="#00FFFF", width=2, tags="player_start",
            )
        
        self.canvas.configure(scrollregion=self.canvas.bbox("all"))
        self.update_cursor_display()
    
    def update_cursor_display(self):
        self.canvas.delete("cursor")
        x1, y1 = self.cursor_x * self.tile_size, self.cursor_y * self.tile_size
        x2, y2 = x1 + self.tile_size, y1 + self.tile_size
        self.canvas.create_rectangle(x1, y1, x2, y2, outline="red", width=3, tags="cursor")
        self.cursor_label.config(text=f"Cursor: ({self.cursor_x}, {self.cursor_y})")
    
    def update_tile_display(self):
        if hasattr(self, 'update_named_trigger_picker'):
            self.update_named_trigger_picker()
        self.tile_canvas.delete("all")
        
        if self.selected_mode == "enemy":
            definitions = self.get_enemy_definitions()
            for index, (enemy_id, definition) in enumerate(definitions.items()):
                y = index * 40 + 10
                sprite_info = self.tile_manager.get_npc_info(
                    definition.get("sprite", "")
                )
                if "image" in sprite_info:
                    self.tile_canvas.create_image(
                        10, y, image=sprite_info["image"], anchor=tk.NW
                    )
                else:
                    self.tile_canvas.create_rectangle(
                        10, y, 40, y + 30, fill="#DC143C", outline="black"
                    )
                self.tile_canvas.create_text(
                    50, y + 15,
                    text=definition.get("name", enemy_id),
                    anchor=tk.W,
                )
                if enemy_id == self.selected_enemy_id:
                    self.tile_canvas.create_rectangle(
                        8, y - 2, 220, y + 32, outline="red", width=2
                    )
        elif self.selected_mode == "tile":
            tiles_per_row = 5
            tile_names = self.tile_manager.get_tile_names()
            for i, tile_name in enumerate(tile_names):
                row, col = i // tiles_per_row, i % tiles_per_row
                x, y = col * 40 + 10, row * 40 + 10
                tile_info = self.tile_manager.get_tile_info(tile_name)
                self.tile_canvas.create_image(x, y, image=tile_info["image"], anchor=tk.NW, tags=f"tile_{tile_name}")
                if tile_name == self.selected_tile:
                    self.tile_canvas.create_rectangle(x-2, y-2, x+34, y+34, outline="red", width=2, tags="selection")
        
        elif self.selected_mode == "npc":
            npc_names = self.tile_manager.get_npc_names() or ["guard", "merchant", "villager", "wizard", "knight"]
            for i, npc_name in enumerate(npc_names):
                y = i * 40 + 10
                npc_info = self.tile_manager.get_npc_info(npc_name)
                if "image" in npc_info:
                    self.tile_canvas.create_image(10, y, image=npc_info["image"], anchor=tk.NW, tags=f"npc_{npc_name}")
                else:
                    colors = {"guard": "#4169E1", "merchant": "#FFD700", "villager": "#90EE90",
                             "wizard": "#9370DB", "knight": "#C0C0C0"}
                    color = colors.get(npc_name, "#FFD700")
                    self.tile_canvas.create_oval(10, y, 40, y + 30, fill=color, outline="black", tags=f"npc_{npc_name}")
                self.tile_canvas.create_text(50, y + 15, text=npc_name.title(), anchor=tk.W)
                if npc_name == self.selected_tile:
                    self.tile_canvas.create_rectangle(8, y-2, 200, y + 32, outline="red", width=2, tags="selection")

        elif self.selected_mode == "player":
            npc_names = self.tile_manager.get_npc_names()
            for i, npc_name in enumerate(npc_names):
                y = i * 40 + 10
                npc_info = self.tile_manager.get_npc_info(npc_name)
                if "image" in npc_info:
                    self.tile_canvas.create_image(
                        10, y, image=npc_info["image"], anchor=tk.NW,
                        tags=f"npc_{npc_name}",
                    )
                self.tile_canvas.create_text(
                    50, y + 15, text=npc_name.replace("_", " ").title(), anchor=tk.W,
                    tags=f"npc_{npc_name}",
                )
                if npc_name == self.selected_tile:
                    self.tile_canvas.create_rectangle(
                        8, y - 2, 200, y + 32, outline="red", width=2,
                        tags="selection",
                    )
        
        elif self.selected_mode == "object":
            obj_names = self.tile_manager.get_object_names() or ["item", "lever", "fountain", "chest", "barrel"]
            for i, obj_name in enumerate(obj_names):
                y = i * 40 + 10
                obj_info = self.tile_manager.get_object_info(obj_name)
                if "image" in obj_info:
                    self.tile_canvas.create_image(10, y, image=obj_info["image"], anchor=tk.NW, tags=f"obj_{obj_name}")
                else:
                    colors = {"item": "#32CD32", "lever": "#FF4500", "fountain": "#00CED1",
                             "chest": "#8B4513", "barrel": "#654321"}
                    color = colors.get(obj_name, "#32CD32")
                    self.tile_canvas.create_rectangle(10, y, 40, y + 30, fill=color, outline="black", tags=f"obj_{obj_name}")
                self.tile_canvas.create_text(50, y + 15, text=obj_info.get("display_name", obj_name.replace("_", " ").title()), anchor=tk.W)
                if obj_name == self.selected_tile:
                    self.tile_canvas.create_rectangle(8, y-2, 200, y + 32, outline="red", width=2, tags="selection")
        
        elif self.selected_mode == "trigger":
            trigger_types = ["teleport", "inventory", "player_stats", "funds", "tile_update", "area_object", "game_end", "show_message", "play_sound", "trigger_control", "enemy_placement", "named_trigger"]
            trigger_names = {
                "teleport": "Teleport",
                "inventory": "Inventory",
                "player_stats": "Player Stats",
                "funds": "Funds",
                "trigger_control": "Trigger Control",
                "enemy_placement": "Enemy Placement",
                "named_trigger": "Named Trigger",
                "tile_update": "Tile Update",
                "area_object": "Area Object", 
                "game_end": "Game End",
                "show_message": "Show Message",
                "play_sound": "Play Sound",
                "custom": "Custom Script"
            }
            
            for i, trigger_type in enumerate(trigger_types):
                y = i * 40 + 10
                color = self.trigger_colors[trigger_type]
                
                # Draw colored diamond preview
                center_x, center_y = 25, y + 20
                self.tile_canvas.create_polygon(center_x, y + 5, 40, center_y, center_x, y + 35, 10, center_y, 
                                              fill=color, outline="black", tags=f"trigger_{trigger_type}")
                self.tile_canvas.create_text(50, y + 20, text=trigger_names[trigger_type], anchor=tk.W)
                
                if trigger_type == self.selected_tile:
                    self.tile_canvas.create_rectangle(8, y-2, 200, y + 32, outline="red", width=2, tags="selection")

        elif self.selected_mode == "messages":
            message_entries = [
                ("intro", "Intro Message"),
                ("instructions", "Help / Instructions Message"),
                ("game_end", "Game End Message"),
            ]
            for i, (message_type, label) in enumerate(message_entries):
                y = i * 55 + 15
                self.tile_canvas.create_text(
                    10,
                    y,
                    text=label,
                    anchor=tk.NW,
                    width=190,
                    tags=f"message_{message_type}",
                )
                self.tile_canvas.create_text(
                    10,
                    y + 22,
                    text="Click to edit",
                    anchor=tk.NW,
                    fill="gray",
                    tags=f"message_{message_type}",
                )

        elif self.selected_mode == "editor_help":
            help_text = (
                "EDITOR HELP\n\n"
                "Tiles, Objects, and NPCs:\n"
                "Choose an item, then use Space to place it at the map cursor. "
                "Right-click or use Edit for Copy, Cut, Paste, and Delete of the entire cell. "
                "Paste replaces the destination tile and everything stacked there.\n\n"
                "Enemies:\n"
                "Use Enemies → Manage Enemies… to create or edit types for this game. "
                "Select a type on the left, then press Space to place it. "
                "The right pane shows a type summary and this instance’s loot choice. "
                "Delete clears the tile and all objects and triggers at the cursor.\n\n"
                "Triggers:\n"
                "Choose a trigger and use Space to add it at the map cursor. "
                "Select stacked triggers "
                "in the right panel (or use 1-9 and 0 for the first ten). "
                "Edit fields in the right panel; Save commits them, and the Delete Trigger button "
                "removes the selected trigger.\n\n"
                "Map navigation (in editing modes):\n"
                "Click a map cell or use the arrow keys to move the cursor. "
                "Messages and Editor Help modes pause map editing.\n\n"
                "Area tools:\n"
                "Use the Area and Tools menus to save, resize, crop, and manage assets."
            )
            self.tile_canvas.create_text(
                10,
                10,
                text=help_text,
                anchor=tk.NW,
                width=190,
                tags="editor_help",
            )
        
        self.tile_canvas.configure(scrollregion=self.tile_canvas.bbox("all"))
        if hasattr(self, 'selected_tile_label'):
            if self.selected_mode == "messages":
                self.selected_tile_label.config(text="Choose a message to edit")
            elif self.selected_mode == "editor_help":
                self.selected_tile_label.config(text="Editor help")
            else:
                self.selected_tile_label.config(text=f"Selected: {self.selected_tile}")
    
    def update_properties_display(self):
        if self.selected_mode == "enemy" and hasattr(self, "refresh_enemy_instance_editor"):
            self.select_enemy_at_cursor()
            if getattr(self, "_enemy_loaded_id", None) != self.selected_enemy_id:
                self.refresh_enemy_editor()
            else:
                self.refresh_enemy_instance_editor()
        self.properties_text.configure(state='normal')
        self.properties_text.delete(1.0, tk.END)
        
        tile = self.current_area.tiles[self.cursor_y][self.cursor_x]
        objects_here = [obj for obj in self.current_area.objects if obj.x == self.cursor_x and obj.y == self.cursor_y]
        triggers_here = [trig for trig in self.current_area.triggers if trig.x == self.cursor_x and trig.y == self.cursor_y]
        
        info = ""
        if triggers_here and 0 <= self.selected_trigger_index < len(triggers_here):
            selected_trigger = triggers_here[self.selected_trigger_index]
            info += f"Selected trigger: {selected_trigger.get_description()}\n\n"
        elif self.selected_mode == "trigger":
            info += (
                f"Trigger type: {self.get_trigger_type_description(self.selected_tile)}\n\n"
            )
        elif self.selected_mode == "object":
            definition = self.current_game.get_object_definition(self.selected_tile)
            info += f"Object definition: {self.selected_tile}\n"
            info += f"Gettable: {definition['gettable']}\n"
            info += f"Walkable: {definition['walkable']}\n"
            info += f"Item type: {definition['item_type']}\n"
            if definition["item_type"] == "weapon":
                info += f"Weapon damage bonus: +{definition['weapon_damage']}\n"
                if definition["ranged"]:
                    info += f"Ranged: {definition['attack_range']} tiles; energy cost {definition['energy_cost']}\n"
            elif definition["item_type"] == "armor":
                info += f"Armor: +{definition['armor_bonus']} ({definition['equipment_slot']})\n"
            if definition["gettable"]:
                info += f"Effect mode: {definition['effect_mode']}\n"
                info += f"Effects: {self._format_object_effects(definition['effects'])}\n\n"
            else:
                info += "Inventory effects: none (object is not gettable)\n\n"

        info += f"Position: ({self.cursor_x}, {self.cursor_y})\n\n"
        tile_info = self.tile_manager.get_tile_info(tile.type)
        global_walkable = self.tile_manager.get_default_walkable(tile.type)
        
        info += f"Tile: {tile_info.get('display_name', tile.type)}\n"
        info += f"Walkable: {tile.is_walkable(self.tile_manager)}\n\n"
        
        self.global_walkable_label.config(text=f"Default: {global_walkable}")
        if tile.walkable_override is None:
            self.walkable_override_var.set("default")
        elif tile.walkable_override:
            self.walkable_override_var.set("walkable")
        else:
            self.walkable_override_var.set("not_walkable")
        
        if objects_here:
            for obj in objects_here:
                info += f"Object: {obj.type}\n"
                if obj.type not in set(self.tile_manager.get_npc_names()):
                    definition = self.current_game.get_object_definition(obj.type)
                    info += f"  Gettable: {definition['gettable']}, Walkable: {definition['walkable']}\n"
                    if definition["gettable"]:
                        info += (
                            f"  Effect mode: {definition['effect_mode']}, "
                            f"Effects: {self._format_object_effects(definition['effects'])}\n"
                        )
        
        if triggers_here:
            info += f"Triggers: ({len(triggers_here)})\n"
            for i, trigger in enumerate(triggers_here):
                selected_marker = "● " if i == self.selected_trigger_index else "  "
                info += f"{selected_marker}{i+1}. {trigger.name} ({trigger.get_description()})\n"
            info += "\nSelect a trigger in the right panel or use number keys 1-9, 0\n"
        
        self.properties_text.insert(1.0, info)
        self.properties_text.configure(state='disabled')

    @staticmethod
    def _format_object_effects(effects):
        active_effects = [
            f"{stat} {value:+d}"
            for stat, value in effects.items()
            if value
        ]
        return ", ".join(active_effects) if active_effects else "none"

    def _triggers_at_cursor(self):
        return [
            trigger for trigger in self.current_area.triggers
            if trigger.x == self.cursor_x and trigger.y == self.cursor_y
        ]

    def add_trigger_at_cursor(self):
        if self.selected_mode != "trigger":
            self.mode_var.set("trigger")
            self.on_mode_change()
        self.place_tile()

    def cycle_selected_trigger(self, direction):
        triggers_here = self._triggers_at_cursor()
        if triggers_here:
            next_index = (self.selected_trigger_index + direction) % len(triggers_here)
            self.select_trigger_index(next_index)

    def on_trigger_list_select(self, _event=None):
        if getattr(self, "_refreshing_trigger_list", False):
            return
        selection = self.trigger_listbox.curselection()
        if selection and not self.select_trigger_index(selection[0]):
            self.trigger_listbox.selection_clear(0, tk.END)
            self.trigger_listbox.selection_set(self.selected_trigger_index)

    def refresh_trigger_editor(self):
        if not hasattr(self, "trigger_listbox"):
            return

        if hasattr(self, "refresh_reusable_triggers"):
            self.refresh_reusable_triggers()
        triggers_here = self._triggers_at_cursor()
        self.selected_trigger_index = min(
            self.selected_trigger_index, max(0, len(triggers_here) - 1)
        )
        self._refreshing_trigger_list = True
        self.trigger_listbox.delete(0, tk.END)
        for index, trigger in enumerate(triggers_here):
            label = f"{index + 1}. {trigger.name} - {trigger.trigger_type.replace('_', ' ').title()}"
            if trigger.definition_id:
                label += " [Named]"
            if not trigger.enabled:
                label += " [Disabled]"
            self.trigger_listbox.insert(tk.END, label)
            self.trigger_listbox.itemconfig(
                index,
                foreground=self.trigger_colors.get(trigger.trigger_type, "#CC0000"),
            )
        if triggers_here:
            self.trigger_listbox.selection_set(self.selected_trigger_index)
            self.trigger_listbox.activate(self.selected_trigger_index)
            self.trigger_listbox.see(self.selected_trigger_index)
        self._refreshing_trigger_list = False

        for child in self.trigger_form_frame.winfo_children():
            child.destroy()
        self._trigger_editor_vars = {}
        self._trigger_editor_tile_labels = {}
        if hasattr(self, 'trigger_save_button'):
            self.trigger_save_button.configure(text='Save')
        if triggers_here:
            selected = triggers_here[self.selected_trigger_index]
            if selected.definition_id and hasattr(self, 'show_named_trigger_summary'):
                self.show_named_trigger_summary(selected)
            else:
                self._build_trigger_editor(selected)
        else:
            ttk.Label(
                self.trigger_form_frame,
                text="Select a trigger tool, then click the map or Add.",
                wraplength=245,
            ).pack(anchor=tk.W, pady=5)

    def move_selected_trigger(self, direction):
        if not self.save_selected_trigger(refresh=False):
            return False
        positions = [index for index, trigger in enumerate(self.current_area.triggers)
                     if (trigger.x, trigger.y) == (self.cursor_x, self.cursor_y)]
        selected = self.selected_trigger_index
        target = selected + direction
        if not (0 <= selected < len(positions) and 0 <= target < len(positions)):
            return False
        first, second = positions[selected], positions[target]
        triggers = self.current_area.triggers
        triggers[first], triggers[second] = triggers[second], triggers[first]
        self.selected_trigger_index = target
        self.refresh_trigger_editor()
        self.draw_area()
        self.update_properties_display()
        return True

    def _change_trigger_editor_type(self, trigger, trigger_type, name):
        trigger_type = self._trigger_editor_type_labels.get(trigger_type, trigger_type)
        if trigger_type == getattr(self, "_trigger_editor_draft_type", trigger.trigger_type):
            return
        charge_variable = self._trigger_editor_vars.get("charges")
        charges = charge_variable.get() if charge_variable is not None else trigger_charges(trigger.parameters)
        for child in self.trigger_form_frame.winfo_children():
            child.destroy()
        self._trigger_editor_vars = {}
        self._trigger_editor_tile_labels = {}
        self._build_trigger_editor(
            trigger, trigger_type=trigger_type, parameters={"charges": charges}, name=name
        )

    def _build_trigger_editor(self, trigger, trigger_type=None, parameters=None, name=None):
        form = self.trigger_form_frame
        self._trigger_editor_trigger = trigger
        trigger_type = trigger_type or trigger.trigger_type
        self._trigger_editor_draft_type = trigger_type
        params = trigger.parameters if parameters is None else parameters
        trigger_types = (
            "teleport",
            "inventory",
            "player_stats",
            "funds",
            "tile_update",
            "area_object",
            "game_end",
            "show_message",
            "play_sound",
            "trigger_control",
            "enemy_placement",
        )
        self._trigger_editor_type_labels = {
            trigger_type.replace("_", " ").title(): trigger_type
            for trigger_type in trigger_types
        }
        trigger_type_var = tk.StringVar(
            value="Custom (unsupported)" if trigger_type == "custom" else trigger_type.replace("_", " ").title()
        )
        self._trigger_editor_vars["trigger_type"] = trigger_type_var
        type_row = ttk.Frame(form)
        type_row.pack(fill=tk.X, pady=2)
        ttk.Label(type_row, text="Type:", width=10).pack(side=tk.LEFT)
        type_combo = ttk.Combobox(
            type_row,
            textvariable=trigger_type_var,
            values=tuple(self._trigger_editor_type_labels),
            state="readonly",
        )
        type_combo.pack(side=tk.LEFT, fill=tk.X, expand=True)
        type_combo.bind(
            "<<ComboboxSelected>>",
            lambda _event: self._change_trigger_editor_type(
                trigger, trigger_type_var.get(), name_var.get()
            ),
        )

        name_var = tk.StringVar(value=trigger.name if name is None else name)
        self._trigger_editor_vars["name"] = name_var
        name_row = ttk.Frame(form)
        name_row.pack(fill=tk.X, pady=2)
        ttk.Label(name_row, text="Name:", width=10).pack(side=tk.LEFT)
        ttk.Entry(name_row, textvariable=name_var).pack(side=tk.LEFT, fill=tk.X, expand=True)

        enabled_var = tk.BooleanVar(value=trigger.enabled)
        self._trigger_editor_vars["enabled"] = enabled_var
        ttk.Checkbutton(form, text="Initially enabled (all placements)" if trigger.definition_id else "Initially enabled", variable=enabled_var).pack(anchor=tk.W)
        if trigger.definition_id and not getattr(self, "editing_named_definition", False):
            ttk.Label(form, text="Named trigger: changes here affect every placement in this game. Delete removes only this placement.", wraplength=245).pack(anchor=tk.W, pady=3)

        def add_entry(key, label, value="", width=16):
            row = ttk.Frame(form)
            row.pack(fill=tk.X, pady=2)
            ttk.Label(row, text=label, width=10).pack(side=tk.LEFT)
            variable = tk.StringVar(value=str(value))
            ttk.Entry(row, textvariable=variable, width=width).pack(
                side=tk.LEFT, fill=tk.X, expand=True
            )
            self._trigger_editor_vars[key] = variable
            return variable

        def add_combo(key, label, values, value="", state="readonly", label_width=10):
            row = ttk.Frame(form)
            row.pack(fill=tk.X, pady=2)
            ttk.Label(row, text=label, width=label_width).pack(side=tk.LEFT)
            variable = tk.StringVar(value=value)
            ttk.Combobox(
                row, textvariable=variable, values=values, state=state, width=16
            ).pack(side=tk.LEFT, fill=tk.X, expand=True)
            self._trigger_editor_vars[key] = variable
            return variable

        def add_text(key, label, value="", height=4):
            ttk.Label(form, text=label).pack(anchor=tk.W, pady=(4, 0))
            text = tk.Text(form, height=height, wrap=tk.WORD)
            text.pack(fill=tk.X, expand=False)
            text.insert("1.0", value)
            self._trigger_editor_vars[key] = text
            return text

        def add_coordinate_picker(x_var, y_var, destination_area_var=None):
            def start_pick():
                destination_area = (
                    destination_area_var.get()
                    if destination_area_var is not None
                    else None
                )
                self._begin_trigger_position_pick(
                    x_var, y_var,
                    None if destination_area == "Current area" else destination_area
                )

            ttk.Button(form, text="Pick coordinates on map", command=start_pick).pack(
                anchor=tk.W, pady=3
            )

        if trigger_type == "teleport":
            area_names = [os.path.splitext(area)[0] for area in self.current_game.areas]
            destination_area_var = add_combo(
                "area", "Area:", area_names, params.get("area", "")
            )
            x_var = add_entry("x", "Target X:", params.get("x", 0))
            y_var = add_entry("y", "Target Y:", params.get("y", 0))
            add_coordinate_picker(x_var, y_var, destination_area_var)
            ttk.Label(form, text="Save destination areas before linking teleports.", wraplength=245).pack(anchor=tk.W, pady=3)
        elif trigger_type == "enemy_placement":
            definitions = self.current_game.properties.get('enemies', {})
            labels = {f"{definition['name']} ({index + 1})": identity for index, (identity, definition) in enumerate(definitions.items())}
            self._enemy_placement_labels = labels
            selected = next((label for label, identity in labels.items() if identity == params.get('enemy_id')), '')
            add_combo('enemy_id', 'Enemy type:', tuple(labels), selected)
            add_combo('action', 'Action:', ('place', 'remove'), params.get('action', 'place'))
            scopes = {'At coordinates': 'position', 'All in this area': 'area', 'All in this game': 'game'}
            self._enemy_placement_scopes = scopes
            scope = next((label for label, value in scopes.items() if value == params.get('scope', 'position')), 'At coordinates')
            add_combo('scope', 'Scope:', tuple(scopes), scope)
            areas = [''] + [os.path.splitext(area)[0] for area in self.current_game.areas]
            destination = add_combo('area', 'Area:', areas, params.get('area', ''))
            x_var = add_entry('x', 'Target X:', params.get('x', trigger.x))
            y_var = add_entry('y', 'Target Y:', params.get('y', trigger.y))
            add_coordinate_picker(x_var, y_var, destination)
            ttk.Label(form, text='Place uses At coordinates. Remove can affect one location, all of a type in an area, or all in this game. Blank area means the area of this trigger. Removal never drops loot.', wraplength=245).pack(anchor=tk.W, pady=4)
        elif trigger_type == "trigger_control":
            labels = {definition['name']: identity for identity, definition in definitions_for(self.current_game).items()}
            self._trigger_control_labels = labels
            target = params.get('target', '')
            selected = next((name for name, identity in labels.items() if identity == target), '')
            add_combo('target', 'Trigger:', tuple(sorted(labels)), selected)
            add_combo('action', 'Action:', ('enable', 'disable'), params.get('action', 'enable'))
            ttk.Label(form, text="Controls every placement of this definition, including other areas. Enabling does not reset charges.", wraplength=245).pack(anchor=tk.W, pady=3)
        elif trigger_type == "funds":
            add_combo("action", "Action:", ("add", "remove"), params.get("action", "add"))
            add_entry("amount", "Amount ($):", params.get("amount", 1))
            ttk.Label(form, text="Use a positive whole amount. Remove fails if funds are insufficient: no money or charge is spent, and later triggers on this tile stop.", wraplength=245).pack(anchor=tk.W, pady=4)
        elif trigger_type == "player_stats":
            stats = [stat for stat in PLAYER_STAT_CHANGES if stat != "gold"]
            if params.get("stat") == "gold":
                stats.append("gold")  # Existing games remain editable; new money triggers use Funds.
            add_combo("stat", "Stat:", stats, params.get("stat", "health"))
            add_entry("amount", "Change (+/-):", params.get("amount", 0))
            ttk.Label(form, text="Use +5 to increase or -5 to decrease. Health and energy stay within their maximums. Zero health ends the game.", wraplength=245).pack(anchor=tk.W, pady=4)
        elif trigger_type == "inventory":
            items = [""] + sorted(set(self.tile_manager.get_object_names())
                                    | set(self.current_game.used_objects)
                                    | set(self.current_game.object_definitions)
                                    | {value for key in ("add", "remove") if (value := params.get(key, ""))})
            add_combo("add", "Add item:", items, params.get("add", ""))
            add_combo("remove", "Remove item:", items, params.get("remove", ""))
            ttk.Label(form, text="Gettable objects pick up automatically. For manual pickup, turn Gettable off and pair this with an Area Object trigger.", wraplength=245).pack(anchor=tk.W, pady=4)
        elif trigger_type == "tile_update":
            area_names = ["Current area"] + [
                os.path.splitext(os.path.basename(area))[0]
                for area in self.current_game.areas
            ]
            destination = add_combo(
                "area", "Area:", area_names, params.get("area") or "Current area"
            )
            x_var = add_entry("x", "Target X:", params.get("x", 0))
            y_var = add_entry("y", "Target Y:", params.get("y", 0))
            tile_name = params.get("tile", "")
            tile_values = {}
            for name in self.tile_manager.get_tile_names():
                display = self.tile_manager.get_tile_info(name).get("display_name", name)
                label = display if display not in tile_values else f"{display} ({name})"
                tile_values[label] = name
            if tile_name and tile_name not in tile_values.values():
                tile_values[tile_name] = tile_name
            selected_label = next(
                (label for label, name in tile_values.items() if name == tile_name), ""
            )
            add_combo("tile", "Change to:", list(tile_values), selected_label)
            self._trigger_editor_tile_labels = tile_values
            current_tile_label = ttk.Label(form, text="")
            current_tile_label.pack(anchor=tk.W, pady=2)

            def update_current_tile(*_args):
                try:
                    target_x, target_y = int(x_var.get()), int(y_var.get())
                except ValueError:
                    current_tile_label.config(text="Current tile: invalid coordinates")
                    return
                target_area = self.current_area
                if destination.get() != "Current area":
                    filename = next(
                        (name for name in self.current_game.areas
                         if destination.get() in (name, os.path.splitext(os.path.basename(name))[0])),
                        None,
                    )
                    if filename is None:
                        current_tile_label.config(text="Current tile: choose an area")
                        return
                    area_path = self._project_path("areas", filename)
                    if not (self.current_area_file and
                            os.path.realpath(self.current_area_file) == os.path.realpath(area_path)):
                        try:
                            target_area = self._read_area_file(area_path)
                        except (OSError, ValueError, KeyError, TypeError):
                            current_tile_label.config(text="Current tile: area unavailable")
                            return
                if not (0 <= target_x < target_area.width and
                        0 <= target_y < target_area.height):
                    current_tile_label.config(text="Current tile: outside this area")
                    return
                current_name = target_area.tiles[target_y][target_x].type
                display_name = self.tile_manager.get_tile_info(current_name).get(
                    "display_name", current_name
                )
                current_tile_label.config(text=f"Current tile: {display_name}")

            destination.trace_add("write", update_current_tile)
            x_var.trace_add("write", update_current_tile)
            y_var.trace_add("write", update_current_tile)
            update_current_tile()
            add_coordinate_picker(x_var, y_var, destination)
            walkable_var = tk.BooleanVar(value=params.get("walkable", True))
            ttk.Checkbutton(form, text="Walkable", variable=walkable_var).pack(anchor=tk.W)
            self._trigger_editor_vars["walkable"] = walkable_var
        elif trigger_type == "area_object":
            area_names = [""] + [os.path.splitext(area)[0] for area in self.current_game.areas]
            destination = add_combo("area", "Area:", area_names, params.get("area", ""))
            add_combo("action", "Action:", ("add", "remove"), params.get("action", "add"))
            objects = sorted(set(self.tile_manager.get_object_names())
                             | set(self.current_game.used_objects)
                             | {value for value in (params.get("object", ""),) if value})
            add_combo("object", "Object:", objects, params.get("object", ""))
            x_var = add_entry("x", "Target X:", params.get("x", trigger.x))
            y_var = add_entry("y", "Target Y:", params.get("y", trigger.y))
            add_coordinate_picker(x_var, y_var, destination)
            ttk.Label(form, text="Blank area means this area. Only the matching object at the target coordinates changes.", wraplength=245).pack(anchor=tk.W, pady=4)
        elif trigger_type == "game_end":
            add_combo("win_lose", "Result:", ("win", "lose"), params.get("win_lose", "win"))
            add_text("message", "Message:", params.get("message", ""), height=3)
        elif trigger_type == "play_sound":
            from pathlib import Path
            import wave
            from project_paths import asset_root
            from wav_assets import import_wav, wav_path
            from ambient_music import AmbientMusic

            library = Path(project_root()) / "sounds"
            files = sorted({path.name for directory in (library, asset_root() / "sounds")
                            for path in directory.glob("*")
                            if path.is_file() and path.suffix.lower() == ".wav"}
                           | ({params["file"]} if params.get("file") else set()))
            row = ttk.Frame(form)
            row.pack(fill=tk.X, pady=2)
            ttk.Label(row, text="WAV file:", width=10).pack(side=tk.LEFT)
            file_var = tk.StringVar(value=params.get("file", ""))
            self._trigger_editor_vars["file"] = file_var
            selector = ttk.Combobox(row, textvariable=file_var, values=files, state="readonly", width=16)
            selector.pack(side=tk.LEFT, fill=tk.X, expand=True)

            def import_sound():
                filename = filedialog.askopenfilename(
                    parent=form.winfo_toplevel(), title="Import Trigger Sound",
                    filetypes=[("WAV audio", "*.wav")],
                )
                if not filename:
                    return
                try:
                    name = import_wav(filename, library)
                    if name not in files:
                        files.append(name)
                    selector.configure(values=sorted(files))
                    file_var.set(name)
                except (OSError, ValueError, wave.Error, EOFError) as error:
                    messagebox.showerror("Import Sound", str(error), parent=form.winfo_toplevel())

            loop_var = tk.BooleanVar(value=params.get("loop", False))
            self._trigger_editor_vars["loop"] = loop_var
            controls = ttk.Frame(form)
            controls.pack(fill=tk.X, pady=3)
            preview = AmbientMusic(
                form.winfo_toplevel(),
                lambda error: messagebox.showerror("Play Sound", error, parent=form.winfo_toplevel()),
                alias="tinker_preview_" + uuid4().hex,
            )

            def play_sound():
                try:
                    wav_path(project_root(), file_var.get())
                except (OSError, ValueError) as error:
                    messagebox.showerror("Play Sound", str(error), parent=form.winfo_toplevel())
                    return
                preview.close()
                preview.update(project_root(), file_var.get(), loop=loop_var.get(), directory="sounds")

            ttk.Button(controls, text="Import WAV", command=import_sound).pack(side=tk.LEFT)
            ttk.Button(controls, text="Play", width=5, command=play_sound).pack(side=tk.LEFT, padx=3)
            ttk.Button(controls, text="Stop", command=preview.close).pack(side=tk.LEFT)
            controls.bind("<Destroy>", lambda _event: preview.close())
            file_var.trace_add("write", lambda *_args: preview.close())
            ttk.Checkbutton(form, text="Loop", variable=loop_var).pack(anchor=tk.W)
            ttk.Label(form, text="Plays once by default. Looping stops when another Play Sound trigger starts or you leave this area.", wraplength=245).pack(anchor=tk.W, pady=3)
        elif trigger_type == "show_message":
            add_text("message", "Message:", params.get("message", ""), height=5)
        elif trigger_type == "custom":
            ttk.Label(form, text="This legacy custom trigger is not supported by the runner. Choose a supported trigger type above or delete it.", wraplength=245).pack(anchor=tk.W, pady=4)

        add_entry("charges", "Charges:", params.get("charges", 1 if params.get("once", False) else 0))
        ttk.Label(form, text="0 = unlimited; 1 = the first successful entry only. Failed actions do not spend charges. Remaining charges are saved with your run.", wraplength=245).pack(anchor=tk.W, pady=3)
        ttk.Label(form, text="Triggers run in list order. A failed trigger stops the remaining actions on this tile.", wraplength=245).pack(anchor=tk.W, pady=3)

        if hasattr(self, "remember_editor_form"):
            self.remember_editor_form("trigger", self._trigger_editor_vars.values())

    def save_selected_trigger(self, show_error=True, refresh=True):
        if getattr(self, "selected_mode", "trigger") != "trigger":
            return True
        trigger = getattr(self, "_trigger_editor_trigger", None)
        variables = getattr(self, "_trigger_editor_vars", {})
        if trigger is None or not variables:
            return True

        parameters = {}
        placement_type = self._trigger_editor_type_labels.get(variables['trigger_type'].get())
        placement_scope = variables['scope'].get() if 'scope' in variables else 'At coordinates'
        for name, variable in variables.items():
            if (placement_type == 'enemy_placement' and name in ('x', 'y')
                    and placement_scope not in ('At coordinates', 'position')):
                continue
            if name in ("name", "trigger_type", "enabled"):
                continue
            if isinstance(variable, tk.Text):
                parameters[name] = variable.get("1.0", tk.END).rstrip("\n")
            elif isinstance(variable, tk.BooleanVar):
                parameters[name] = variable.get()
            else:
                value = variable.get()
                if name in ("x", "y", "amount", "charges"):
                    try:
                        value = int(value)
                    except ValueError:
                        if show_error:
                            messagebox.showerror(
                                "Invalid Trigger Value",
                                f"{name.replace('_', ' ').title()} must be a whole number.",
                            )
                        return False
                parameters[name] = value

        trigger_type = self._trigger_editor_type_labels.get(
            variables["trigger_type"].get()
        )
        if (trigger_type is None and trigger.trigger_type == "custom"
                and variables["trigger_type"].get() == "Custom (unsupported)"):
            trigger_type = "custom"
            parameters = {**trigger.parameters, **parameters}
        if trigger_type is None:
            if show_error:
                messagebox.showerror("Invalid Trigger Type", "Choose a valid trigger type.")
            return False
        if trigger_type == "play_sound":
            from wav_assets import wav_path
            try:
                wav_path(project_root(), parameters.get("file"))
            except (OSError, ValueError) as error:
                if show_error:
                    messagebox.showerror("Play Sound", str(error))
                return False
        if trigger_type == "funds":
            try:
                funds_delta(parameters)
            except ValueError as error:
                if show_error:
                    messagebox.showerror("Invalid Funds", str(error))
                return False
        if trigger_type == "player_stats" and parameters.get("stat") not in PLAYER_STAT_CHANGES:
            if show_error:
                messagebox.showerror("Invalid Stat", "Choose a player stat.")
            return False
        if trigger_type == "tile_update":
            if parameters.get("area") == "Current area":
                parameters["area"] = ""
            selected_tile = self._trigger_editor_tile_labels.get(
                parameters.get("tile", "")
            )
            if not selected_tile:
                if show_error:
                    messagebox.showerror(
                        "Select a Tile", "Choose the tile to change the target to."
                    )
                return False
            parameters["tile"] = selected_tile

        if trigger_type == "enemy_placement":
            definitions = self.current_game.properties.get('enemies', {})
            selected = parameters.get('enemy_id', '')
            parameters['enemy_id'] = selected if selected in definitions else getattr(self, '_enemy_placement_labels', {}).get(selected, '')
            parameters['scope'] = getattr(self, '_enemy_placement_scopes', {}).get(parameters.get('scope'), parameters.get('scope', 'position'))
            if (parameters['enemy_id'] not in definitions or parameters.get('action') not in ('place', 'remove')
                    or parameters['scope'] not in ('position', 'area', 'game')
                    or (parameters['action'] == 'place' and parameters['scope'] != 'position')):
                if show_error:
                    messagebox.showerror('Enemy Placement', 'Choose an enemy type and valid scope. Place uses At coordinates.')
                return False

        if trigger_type == "trigger_control":
            definitions = definitions_for(self.current_game)
            selected = parameters.get('target', '')
            # Resolve against the current library, not only the form's cached
            # name-to-ID map, which can become stale after refreshes/renames.
            target = selected if selected in definitions else next(
                (identity for identity, definition in definitions.items()
                 if definition['name'] == selected), '')
            if not target:
                cached = getattr(self, '_trigger_control_labels', {}).get(selected, '')
                if cached in definitions:
                    target = cached
            parameters['target'] = target
            try:
                validate_control(parameters, definitions_for(self.current_game))
            except ValueError as error:
                if show_error:
                    messagebox.showerror('Trigger Control', str(error))
                return False

        try:
            trigger_charges(parameters)
        except ValueError as error:
            if show_error:
                messagebox.showerror("Invalid Charges", str(error))
            return False
        coordinate_error = self._trigger_coordinate_error(trigger_type, parameters)
        if coordinate_error:
            if show_error:
                messagebox.showerror("Invalid Coordinates", coordinate_error)
            return False

        name = variables["name"].get().strip()
        if trigger.definition_id and hasattr(self, 'reusable_name_available') and not self.reusable_name_available(name, trigger.definition_id):
            if show_error:
                messagebox.showerror('Named Trigger', 'Choose a unique, nonempty name for this game.')
            return False
        trigger.name = name
        if 'enabled' in variables:
            trigger.enabled = variables['enabled'].get()
        trigger.trigger_type = trigger_type
        trigger.parameters = parameters
        if hasattr(self, "save_reusable_trigger"):
            self.save_reusable_trigger(trigger)
        if hasattr(self, "remember_editor_form"):
            self.remember_editor_form("trigger", variables.values())
        if refresh:
            self.refresh_trigger_editor()
            self.update_properties_display()
            self.draw_area()
        return True

    def delete_selected_trigger(self, confirm=False):
        triggers_here = self._triggers_at_cursor()
        if not triggers_here or not 0 <= self.selected_trigger_index < len(triggers_here):
            return False
        if confirm and not messagebox.askyesno(
            "Delete Trigger", "Delete the selected trigger?"
        ):
            return False

        trigger = triggers_here[self.selected_trigger_index]
        self.current_area.triggers.remove(trigger)
        remaining = self._triggers_at_cursor()
        self.selected_trigger_index = min(
            self.selected_trigger_index, max(0, len(remaining) - 1)
        )
        self._trigger_editor_trigger = None
        self._trigger_editor_vars = {}
        self.refresh_trigger_editor()
        self.update_properties_display()
        self.draw_area()
        return True

    def _trigger_coordinate_error(self, trigger_type, parameters):
        if trigger_type == 'enemy_placement':
            if parameters.get('scope') == 'game':
                return None
            if parameters.get('scope') == 'area':
                area = parameters.get('area', '')
                if not area or any(area in (name, os.path.splitext(os.path.basename(name))[0]) for name in self.current_game.areas):
                    return None
                return 'Choose an area in this game.'
        if trigger_type in ("area_object", "tile_update", "enemy_placement") and not parameters.get("area"):
            x, y = parameters["x"], parameters["y"]
            if not (0 <= x < self.current_area.width and 0 <= y < self.current_area.height):
                return "Coordinates must be within this area."
            return None
        if trigger_type in ("teleport", "area_object", "tile_update", "enemy_placement"):
            selected_area = parameters.get("area", "")
            area_filename = next(
                (area for area in self.current_game.areas
                 if area == selected_area or os.path.splitext(os.path.basename(area))[0] == selected_area),
                None
            )
            if not area_filename:
                return "Select a destination area that belongs to this game."
            area_path = os.path.join(
                project_root(), "areas", area_filename
            )
            if (self.current_area_file and
                    os.path.realpath(self.current_area_file) == os.path.realpath(area_path)):
                destination_width = self.current_area.width
                destination_height = self.current_area.height
            else:
                try:
                    with open(area_path, 'r') as f:
                        destination_area = json.load(f)
                    destination_width = int(destination_area["width"])
                    destination_height = int(destination_area["height"])
                except FileNotFoundError:
                    if trigger_type == "teleport":
                        return "Save the destination area before linking a teleport to it."
                    return "Save the destination area before targeting it with this trigger."
                except (OSError, KeyError, TypeError, ValueError) as e:
                    return f"Could not read destination area dimensions: {e}"
        else:
            return None
        x, y = parameters["x"], parameters["y"]
        if not (0 <= x < destination_width and 0 <= y < destination_height):
            return (
                "Coordinates must be within the destination area "
                f"(X: 0-{destination_width - 1}, Y: 0-{destination_height - 1})."
            )
        return None
